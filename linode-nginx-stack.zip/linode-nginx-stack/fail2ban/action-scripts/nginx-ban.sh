#!/bin/sh
# Adds a banned IP to nginx's deny list and reloads it — replaces
# iptables entirely, since iptables/nftables on this host are already
# managed by SoftEther, WireGuard, and Tailscale, and Tailscale is
# confirmed to silently wipe rules other tools add there directly.
set -eu

IP="$1"
DENYLIST="/nginx-conf-shared/conf.d/fail2ban-denylist.conf"
ESCAPED_IP=$(printf '%s' "$IP" | sed 's/\./\\./g')

mkdir -p "$(dirname "$DENYLIST")"
touch "$DENYLIST"

if ! grep -qE "deny ${ESCAPED_IP};" "$DENYLIST" 2>/dev/null; then
  echo "deny ${IP};" >> "$DENYLIST"
fi

docker exec nginx-ui nginx -s reload
