#!/bin/sh
# Adds a banned IP to nginx's deny list and reloads it — replaces
# iptables entirely, since iptables/nftables on this host are already
# managed by SoftEther, WireGuard, and Tailscale, and Tailscale is
# confirmed to silently wipe rules other tools add there directly.
#
# IPv6: one connection usually owns a whole /64 and can hop to the next
# address after each ban, so the deny line covers the address's
# F2B_IPV6_BAN_PREFIX block (default /64). Every line ends with the exact
# address that caused it ("# <ip>"), so unbanning removes only its own line.
set -eu

IP="$1"
DENYLIST="/nginx-conf-shared/conf.d/fail2ban-denylist.conf"

NET="$IP"
case "$IP" in
  *:*)
    PREFIX="${F2B_IPV6_BAN_PREFIX:-64}"
    case "$PREFIX" in ''|*[!0-9]*) PREFIX=64 ;; esac
    if [ "$PREFIX" -lt 16 ] || [ "$PREFIX" -gt 128 ]; then PREFIX=64; fi
    NET=$(python3 -c 'import ipaddress, sys; print(ipaddress.ip_network(sys.argv[1] + "/" + sys.argv[2], strict=False))' "$IP" "$PREFIX" 2>/dev/null) || NET="$IP"
    ;;
esac
LINE="deny ${NET}; # ${IP}"

mkdir -p "$(dirname "$DENYLIST")"
touch "$DENYLIST"

if ! grep -qxF "$LINE" "$DENYLIST" 2>/dev/null; then
  echo "$LINE" >> "$DENYLIST"
fi

docker exec nginx-ui nginx -s reload
