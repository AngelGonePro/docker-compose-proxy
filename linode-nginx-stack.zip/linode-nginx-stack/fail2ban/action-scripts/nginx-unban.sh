#!/bin/sh
# Removes only the line(s) this exact address created: "deny <net>; # <ip>",
# or the older "deny <ip>;" form. Another banned address in the same IPv6
# block keeps its own line, so it stays blocked until its own ban ends.
set -eu

IP="$1"
DENYLIST="/nginx-conf-shared/conf.d/fail2ban-denylist.conf"
# "all" (nginx-denylist-all): also the stream ports' list
STREAM_DENYLIST="/nginx-conf-shared/streams-enabled/fail2ban-stream-denylist.conf"
LISTS="$DENYLIST"
[ "${2:-}" = all ] && LISTS="$DENYLIST $STREAM_DENYLIST"

for L in $LISTS; do
  [ -f "$L" ] || continue
  awk -v ip="$IP" '
    BEGIN { old = "deny " ip ";"; tag = "; # " ip }
    $0 == old { next }
    length($0) >= length(tag) && substr($0, length($0) - length(tag) + 1) == tag { next }
    { print }
  ' "$L" > "$L.tmp" && cat "$L.tmp" > "$L"
  rm -f "$L.tmp"
done

sh /action-scripts/nginx-reload.sh || echo "nginx reload failed — the ban list is updated and takes effect on the next reload" >&2
