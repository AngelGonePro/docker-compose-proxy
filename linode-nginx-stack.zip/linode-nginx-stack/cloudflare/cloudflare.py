#!/usr/bin/env python3
"""Cloudflare helper — two jobs, each switched on in .env / docker-compose.yml.

1. Real visitor IPs (CF_REALIP=true; the Linode stack turns this on)
   Writes nginx-conf/conf.d/cloudflare-realip.conf so nginx sees the visitor's
   real address (IPv4 and IPv6) instead of Cloudflare's or cloudflared's:
     * Cloudflare's edge ranges (proxied DNS records reaching nginx directly),
       refreshed from cloudflare.com every CF_RANGES_REFRESH_HOURS; a failed
       or empty download keeps the last good copy.
     * cloudflared (Cloudflare Tunnel) on this host — CLOUDFLARED_SOURCE_IPS,
       or "auto": found through Docker (host network -> 127.0.0.1/::1, otherwise
       the container's own addresses), re-checked every CF_REALIP_CHECK_SECONDS
       so a restarted cloudflared with a new address is picked up.
   nginx trusts CF-Connecting-IP only from those addresses, so nobody else can
   fake it. A changed file is only kept if `nginx -t` passes; otherwise the
   previous one is put back and nothing reloads.

2. Ban sync (CF_BAN_SYNC=true) — fail2ban bans -> one Cloudflare IP list
   Reads this stack's live fail2ban deny lists (exactly what nginx is blocking
   right now) and mirrors them into the account's IP list CF_BAN_LIST_NAME, so
   a WAF custom rule "ip.src in $<list>" blocks them at Cloudflare's edge too.
     * Each machine only adds and removes its OWN entries, tagged in the item
       comment ("ban-sync:<CF_BAN_SYNC_SOURCE> ..."). The Linode and home stacks
       share one list without ever overwriting each other.
     * An IP the other machine already lists isn't added twice; if that one
       drops it, the next sync here adds it back.
     * Unbanned, expired, or gone after a container update: removed from
       Cloudflare (after two checks in a row, so a restart in progress
       doesn't cause churn).
     * IPv6 bans are the same /64 nginx blocks.
     * Never sent: private/LAN, CGNAT/Tailscale, loopback, link-local, Cloudflare's
       own ranges, FAIL2BAN_WHITELIST_IPS, RATE_LIMIT_WHITELIST_IPS.
     * CF_BAN_SYNC=false removes this machine's entries from the list, once.
"""
import http.client
import ipaddress
import json
import os
import random
import re
import signal
import socket
import sys
import time
import urllib.error
import urllib.request

API = os.environ.get("CF_API_BASE", "https://api.cloudflare.com/client/v4").rstrip("/")
STATE = os.environ.get("STATE_DIR", "/state")
UA = "nginx-stack-cloudflare/1.0 (+https://github.com/AngelGonePro/docker-compose-proxy)"

PROTECTED = [ipaddress.ip_network(n) for n in (
    "0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16",
    "172.16.0.0/12", "192.168.0.0/16", "224.0.0.0/4", "240.0.0.0/4",
    "::/128", "::1/128", "fc00::/7", "fe80::/10", "ff00::/8", "::ffff:0:0/96")]


# ------------------------------------------------------------------ helpers ---
def env(k, d=""):
    v = os.environ.get(k, "").strip()
    return v if v else d


def env_int(k, d):
    try:
        return int(env(k, str(d)))
    except ValueError:
        return d


def env_bool(k, d):
    v = env(k, "")
    return d if v == "" else v.lower() in ("1", "true", "yes", "on")


def words(v):
    return [w for w in re.split(r"[\s,]+", v or "") if w]


def log(msg):
    print(f"[cloudflare] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}", flush=True)


def net(text):
    try:
        return ipaddress.ip_network(str(text).strip(), strict=False)
    except ValueError:
        return None


def cf_item_text(n):
    """How an entry is written to Cloudflare: plain address for one IPv4/IPv6
    host, CIDR otherwise."""
    if n.prefixlen == n.max_prefixlen:
        return str(n.network_address)
    return str(n)


def load_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


# ------------------------------------------------------------ docker API ---
class UnixHTTPConnection(http.client.HTTPConnection):
    def __init__(self, path, timeout=30):
        super().__init__("localhost", timeout=timeout)
        self.path_ = path

    def connect(self):
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(self.timeout)
        s.connect(self.path_)
        self.sock = s


def docker(method, path, body=None, timeout=30):
    sock = env("DOCKER_SOCKET", "/var/run/docker.sock")
    c = UnixHTTPConnection(sock, timeout)
    try:
        data = json.dumps(body).encode() if body is not None else None
        c.request(method, path, body=data, headers={"Content-Type": "application/json", "Host": "docker"})
        r = c.getresponse()
        raw = r.read()
        return r.status, raw
    finally:
        c.close()


def nginx_exec(args):
    """Run nginx with args inside the nginx-ui container. -> (ok, output)"""
    c = env("NGINX_CONTAINER", "nginx-ui")
    st, raw = docker("POST", f"/containers/{c}/exec",
                     {"Cmd": ["nginx"] + args, "AttachStdout": True, "AttachStderr": True})
    if st != 201:
        return False, f"docker exec create failed ({st}): {raw[:200]!r}"
    eid = json.loads(raw)["Id"]
    st, out = docker("POST", f"/exec/{eid}/start", {"Detach": False, "Tty": False}, timeout=60)
    # strip Docker's 8-byte stream frame headers
    text, i = b"", 0
    while i + 8 <= len(out):
        size = int.from_bytes(out[i + 4:i + 8], "big")
        text += out[i + 8:i + 8 + size]
        i += 8 + size
    for _ in range(40):
        st, raw = docker("GET", f"/exec/{eid}/json")
        info = json.loads(raw) if st == 200 else {}
        if info and not info.get("Running"):
            return info.get("ExitCode") == 0, text.decode("utf-8", "replace").strip()
        time.sleep(0.25)
    return False, "nginx didn't finish in time"


# ===================================================== 1. real visitor IPs ===
def http_get(url, timeout=30):
    if url.startswith("file://"):
        with open(url[7:], "rb") as f:
            return f.read()
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def cloudflare_ranges():
    """Cloudflare's published edge ranges, cached; a bad download keeps the cache."""
    path = os.path.join(STATE, "cloudflare-ranges.json")
    cache = load_json(path, {})
    every = max(1, env_int("CF_RANGES_REFRESH_HOURS", 24)) * 3600
    if cache.get("ranges") and time.time() - cache.get("t", 0) < every:
        return cache["ranges"]
    if time.time() - cache.get("tried", 0) < 600 and cache.get("ranges"):
        return cache["ranges"]
    cache["tried"] = time.time()
    got = []
    try:
        for url in (env("CF_IPS_V4_URL", "https://www.cloudflare.com/ips-v4"),
                    env("CF_IPS_V6_URL", "https://www.cloudflare.com/ips-v6")):
            got += [str(n) for n in (net(l) for l in http_get(url).decode().split()) if n]
    except (OSError, urllib.error.URLError, ValueError) as e:
        log(f"couldn't download Cloudflare's IP ranges ({e}) — keeping the previous copy")
        got = []
    v4 = [g for g in got if ":" not in g]
    v6 = [g for g in got if ":" in g]
    prev = cache.get("ranges") or []
    if v4 and v6 and (not prev or len(got) >= len(prev) // 2):
        if sorted(got) != sorted(prev):
            log(f"Cloudflare edge ranges: {len(v4)} IPv4, {len(v6)} IPv6")
        cache["ranges"], cache["t"] = got, time.time()
    elif got:
        log("Cloudflare's IP range download looked wrong (missing IPv4 or IPv6, or much shorter) — keeping the previous copy")
    save_json(path, cache)
    return cache.get("ranges") or []


def cloudflared_sources():
    """Addresses cloudflared connects to nginx from."""
    setting = env("CLOUDFLARED_SOURCE_IPS", "auto")
    if setting.lower() != "auto":
        return sorted({str(n) for n in (net(w) for w in words(setting)) if n})
    found = set()
    try:
        st, raw = docker("GET", "/containers/json")
        if st != 200:
            raise OSError(f"docker API {st}")
        for c in json.loads(raw):
            label = (c.get("Image", "") + " " + " ".join(c.get("Names", []))).lower()
            if "cloudflared" not in label:
                continue
            st, raw = docker("GET", f"/containers/{c['Id']}/json")
            if st != 200:
                continue
            info = json.loads(raw)
            if (info.get("HostConfig") or {}).get("NetworkMode") == "host":
                found.update(("127.0.0.1", "::1"))
            for n in ((info.get("NetworkSettings") or {}).get("Networks") or {}).values():
                for k in ("IPAddress", "GlobalIPv6Address"):
                    if n.get(k):
                        found.add(n[k])
    except (OSError, ValueError, KeyError) as e:
        log(f"couldn't look up cloudflared through Docker ({e}) — set CLOUDFLARED_SOURCE_IPS in .env")
    return sorted(found)


def realip_conf(ranges, sources):
    lines = ["# Generated by the cloudflare service on every check — edit .env",
             "# (CLOUDFLARED_SOURCE_IPS), not this file. nginx takes the visitor's real",
             "# address from CF-Connecting-IP, but only on connections from these:",
             "", "# cloudflared (Cloudflare Tunnel) on this host"]
    lines += [f"set_real_ip_from {s};" for s in sources] or ["# (none found)"]
    lines += ["", "# Cloudflare's edge (proxied DNS records reaching nginx directly)"]
    lines += [f"set_real_ip_from {r};" for r in ranges] or ["# (not downloaded yet)"]
    lines += ["", "real_ip_header CF-Connecting-IP;", ""]
    return "\n".join(lines)


class RealIP:
    def __init__(self):
        self.path = env("CF_REALIP_FILE", "/nginx-conf/conf.d/cloudflare-realip.conf")
        self.last_sources = None

    def run(self):
        # nginx-ui sets /etc/nginx up only when that folder is completely
        # empty on its first start — never write into it before that.
        if not os.path.isfile(os.path.join(os.path.dirname(os.path.dirname(self.path)), "nginx.conf")):
            if not getattr(self, "waiting_logged", False):
                log("waiting for nginx-ui's first start before writing the real-IP config")
                self.waiting_logged = True
            return
        ranges = cloudflare_ranges()
        sources = cloudflared_sources()
        if sources != self.last_sources:
            log("cloudflared (Cloudflare Tunnel) connects from: " + (", ".join(sources) or "nothing found — tunnel visitors keep cloudflared's address"))
            self.last_sources = sources
        new = realip_conf(ranges, sources)
        try:
            with open(self.path) as f:
                old = f.read()
        except OSError:
            old = None
        if old == new:
            return
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w") as f:
            f.write(new)
        os.replace(tmp, self.path)
        ok, out = nginx_exec(["-t"])
        if not ok:
            log("nginx -t failed with the new real-IP config — putting the previous one back:\n" + out)
            if old is None:
                os.remove(self.path)
            else:
                with open(tmp, "w") as f:
                    f.write(old)
                os.replace(tmp, self.path)
            return
        ok, out = nginx_exec(["-s", "reload"])
        log("real-IP config updated and nginx reloaded" if ok else "real-IP config updated, but nginx reload failed: " + out)


# ============================================================ 2. ban sync ===
class CFError(Exception):
    pass


def cf(method, path, body=None, token=None, timeout=30):
    req = urllib.request.Request(API + path, method=method,
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Authorization": f"Bearer {token}",
                                          "Content-Type": "application/json", "User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            data = json.loads(e.read() or b"{}")
        except ValueError:
            data = {}
        errs = "; ".join(f"{x.get('code')}: {x.get('message')}" for x in data.get("errors") or []) or str(e)
        raise CFError(f"HTTP {e.code} — {errs}")
    except (OSError, urllib.error.URLError, ValueError) as e:
        raise CFError(str(e))
    if not data.get("success", False):
        errs = "; ".join(f"{x.get('code')}: {x.get('message')}" for x in data.get("errors") or [])
        raise CFError(errs or "request failed")
    return data


def read_denylists(paths):
    """Live bans: 'deny <net>; # <ip>' (or older 'deny <ip>;') lines -> {net: ip}"""
    out = {}
    for p in paths:
        try:
            with open(p) as f:
                for line in f:
                    m = re.match(r"\s*deny\s+([0-9a-fA-F.:/]+)\s*;(?:\s*#\s*([0-9a-fA-F.:]+))?", line)
                    if not m:
                        continue
                    n = net(m.group(1))
                    if n:
                        out.setdefault(n, m.group(2) or str(n.network_address))
        except FileNotFoundError:
            continue                      # no bans yet
    return out


class BanSync:
    def __init__(self):
        self.token = env("CF_BAN_SYNC_API_TOKEN") or env("CF_API_TOKEN")
        self.list_name = env("CF_BAN_LIST_NAME", "fail2ban_bans")
        self.source = re.sub(r"[^A-Za-z0-9_.-]", "_", env("CF_BAN_SYNC_SOURCE", socket.gethostname()))[:40]
        self.tag = f"ban-sync:{self.source}"
        self.enabled = env_bool("CF_BAN_SYNC", False)
        self.paths = words(env("CF_BAN_DENYLISTS", "/nginx-conf/conf.d/fail2ban-denylist.conf"))
        self.max_items = env_int("CF_BAN_SYNC_MAX_ITEMS", 5000)
        self.account = env("CF_ACCOUNT_ID")
        self.list_id = None
        self.missing_once = set()         # mine, absent from the deny lists last check
        self.backoff_until = 0
        self.cleaned = False
        self.state_path = os.path.join(STATE, "ban-sync.json")
        self.never = list(PROTECTED) + [n for n in (net(w) for w in
                    words(env("FAIL2BAN_WHITELIST_IPS")) + words(env("RATE_LIMIT_WHITELIST_IPS"))) if n]

    def configured(self):
        return bool(self.token) and "your_cloudflare" not in self.token

    def call(self, method, path, body=None):
        return cf(method, path, body, self.token)

    def find_account(self):
        if self.account:
            return self.account
        dom = env("ROOT_DOMAIN")
        if not dom:
            raise CFError("set CF_ACCOUNT_ID (or ROOT_DOMAIN) in .env")
        try:
            res = self.call("GET", f"/zones?name={dom}")["result"]
        except CFError as e:
            raise CFError(f"couldn't look up the account for {dom} ({e}) — set CF_ACCOUNT_ID in .env "
                          "(Cloudflare dashboard → your domain → Overview → Account ID), or give the token Zone → Zone → Read")
        if not res:
            raise CFError(f"zone {dom} isn't visible to this token — set CF_ACCOUNT_ID in .env")
        self.account = res[0]["account"]["id"]
        return self.account

    def lookup_list(self, acc):
        for l in self.call("GET", f"/accounts/{acc}/rules/lists")["result"]:
            if l.get("name") == self.list_name:
                if l.get("kind") != "ip":
                    raise CFError(f"list {self.list_name} exists but isn't an IP list — set another CF_BAN_LIST_NAME")
                return l["id"]
        return None

    def find_list(self):
        if self.list_id:
            return self.list_id
        acc = self.find_account()
        self.list_id = self.lookup_list(acc)
        if self.list_id:
            return self.list_id
        try:
            r = self.call("POST", f"/accounts/{acc}/rules/lists",
                          {"name": self.list_name, "kind": "ip",
                           "description": "fail2ban bans from the Linode + home nginx stacks (synced automatically)"})
        except CFError as e:
            # the other machine may have created it a moment ago
            time.sleep(1 + random.random() * 2)
            self.list_id = self.lookup_list(acc)
            if self.list_id:
                return self.list_id
            raise CFError(f"couldn't create the IP list '{self.list_name}' ({e}). The free plan allows ONE custom list: "
                          "if you already have one, set CF_BAN_LIST_NAME to its name")
        self.list_id = r["result"]["id"]
        log(f"created Cloudflare IP list '{self.list_name}' — add the WAF custom rule (ip.src in ${self.list_name} → Block) once, see README")
        return self.list_id

    def items(self):
        acc, lid = self.find_account(), self.find_list()
        out, cursor = [], None
        for _ in range(200):
            q = "?per_page=500" + (f"&cursor={urllib.request.quote(cursor)}" if cursor else "")
            d = self.call("GET", f"/accounts/{acc}/rules/lists/{lid}/items{q}")
            out += d.get("result") or []
            cursor = (((d.get("result_info") or {}).get("cursors")) or {}).get("after")
            if not cursor:
                break
        return out

    def bulk(self, method, body, what):
        """POST/DELETE items, then wait for the async operation. Only one bulk
        operation per account may run, and two machines share it: on a refusal,
        wait a random few seconds and try again."""
        acc, lid = self.find_account(), self.find_list()
        for attempt in range(6):
            try:
                op = self.call(method, f"/accounts/{acc}/rules/lists/{lid}/items", body)["result"]["operation_id"]
                break
            except CFError as e:
                if attempt == 5:
                    raise CFError(f"{what}: {e}")
                time.sleep(2 + attempt * 3 + random.random() * 4)
        for _ in range(120):
            st = self.call("GET", f"/accounts/{acc}/rules/lists/bulk_operations/{op}")["result"]
            if st.get("status") == "completed":
                return
            if st.get("status") == "failed":
                raise CFError(f"{what} failed at Cloudflare: {st.get('error')}")
            time.sleep(1)
        raise CFError(f"{what}: Cloudflare didn't finish in 2 minutes")

    def allowed(self, n):
        return not any(n.version == p.version and n.overlaps(p) for p in self.never)

    def wanted(self):
        bans = read_denylists(self.paths)
        cf_edges = [n for n in (net(r) for r in load_json(os.path.join(STATE, "cloudflare-ranges.json"), {}).get("ranges", [])) if n]
        out = {}
        for n, ip in bans.items():
            if not self.allowed(n) or any(n.version == e.version and n.overlaps(e) for e in cf_edges):
                continue
            if n.version == 6 and n.prefixlen < 12:
                continue
            if n.version == 4 and n.prefixlen < 8:
                continue
            out[cf_item_text(n)] = ip
        if len(out) > self.max_items:
            keys = list(out)[-self.max_items:]          # newest bans are at the end of the files
            log(f"{len(out)} bans — only the newest {self.max_items} go to Cloudflare (CF_BAN_SYNC_MAX_ITEMS)")
            out = {k: out[k] for k in keys}
        return out

    def run(self):
        if time.time() < self.backoff_until or not self.configured():
            return
        try:
            if not self.enabled:
                if not self.cleaned and os.path.exists(self.state_path):
                    mine = [i for i in self.items() if (i.get("comment") or "").startswith(self.tag + " ")]
                    if mine:
                        self.bulk("DELETE", {"items": [{"id": i["id"]} for i in mine]}, "removing this machine's entries")
                        log(f"CF_BAN_SYNC is off — removed this machine's {len(mine)} entries from '{self.list_name}'")
                    os.remove(self.state_path)
                self.cleaned = True
                return
            want = self.wanted()
            items = self.items()
            listed = {}
            for i in items:
                n = net(i.get("ip"))
                if n:
                    listed.setdefault(cf_item_text(n), []).append(i)
            mine = {cf_item_text(net(i["ip"])): i for i in items
                    if net(i.get("ip")) and (i.get("comment") or "").startswith(self.tag + " ")}
            gone = {k for k in mine if k not in want}
            remove = [mine[k] for k in gone if k in self.missing_once]   # absent twice in a row
            self.missing_once = gone
            add = [{"ip": k, "comment": f"{self.tag} {ip}"[:500]} for k, ip in want.items() if k not in listed]
            if remove:
                self.bulk("DELETE", {"items": [{"id": i["id"]} for i in remove]}, "removing unbanned entries")
                log(f"removed {len(remove)} unbanned: " + ", ".join(i["ip"] for i in remove[:10]) + (" …" if len(remove) > 10 else ""))
            if add:
                for i in range(0, len(add), 1000):
                    self.bulk("POST", add[i:i + 1000], "adding bans")
                log(f"added {len(add)} ban(s): " + ", ".join(a["ip"] for a in add[:10]) + (" …" if len(add) > 10 else ""))
            save_json(self.state_path, {"t": int(time.time()), "mine": len(mine) - len(remove) + len(add)})
        except CFError as e:
            msg = str(e)
            if "HTTP 401" in msg or "HTTP 403" in msg or "Authentication" in msg:
                msg += (" — the token needs Account → Account Filter Lists → Edit (Cloudflare dashboard → "
                        "My Profile → API Tokens → edit the token), or set CF_BAN_SYNC_API_TOKEN to one that has it")
                self.backoff_until = time.time() + 600
            else:
                self.backoff_until = time.time() + 120
            self.list_id = None if "list" in msg.lower() else self.list_id
            log("ban sync: " + msg)


# ================================================================= main ===
def main():
    os.makedirs(STATE, exist_ok=True)
    stop = []
    signal.signal(signal.SIGTERM, lambda *_: stop.append(1))
    realip = RealIP() if env_bool("CF_REALIP", False) else None
    sync = BanSync()
    jobs = []
    if realip:
        jobs.append((realip, max(30, env_int("CF_REALIP_CHECK_SECONDS", 300))))
        log("real-IP config: on (" + realip.path + ")")
    if sync.configured():
        jobs.append((sync, max(30, env_int("CF_BAN_SYNC_SECONDS", 60))))
        log(f"ban sync: {'on' if sync.enabled else 'off'} — list '{sync.list_name}', this machine's entries tagged '{sync.tag}'")
    else:
        log("ban sync: no Cloudflare API token in .env (CF_BAN_SYNC_API_TOKEN / CF_API_TOKEN) — not syncing")
    if not jobs:
        log("nothing to do — idle")
    due = [0] * len(jobs)
    while not stop:
        for i, (job, every) in enumerate(jobs):
            if time.time() >= due[i]:
                try:
                    job.run()
                except Exception as e:       # never let one bad cycle kill the service
                    log(f"{job.__class__.__name__}: unexpected error {e.__class__.__name__}: {e}")
                due[i] = time.time() + every
        time.sleep(1)
    log("stopped")


if __name__ == "__main__":
    sys.exit(main())
