#!/bin/sh
# Runs after every successful certbot issuance/renewal. Copies the fresh
# cert files as REGULAR FILES into the shared nginx-conf/ host directory
# (mounted as /etc/nginx in nginx-ui and bootstrap) instead of bind-mounting
# them there directly. A separate nested bind mount under /etc/nginx would
# make nginx-ui's own "is /etc/nginx completely empty?" first-boot check
# always see it as non-empty, permanently breaking its seed logic — this
# keeps that check meaningful while still satisfying nginx-ui's requirement
# that imported cert paths live under its own nginx conf dir.
set -eu

SRC="/etc/letsencrypt/live/${ROOT_DOMAIN}"
DEST="/nginx-conf-shared/ssl/letsencrypt/live/${ROOT_DOMAIN}"

mkdir -p "$DEST"
cp -p "$SRC/fullchain.pem" "$DEST/fullchain.pem"
cp -p "$SRC/privkey.pem" "$DEST/privkey.pem"

"$@"
