#!/bin/sh
# Build step (see Dockerfile): make sure this image's nginx has the fixes for
# CVE-2026-123007 / CVE-2026-123633 (HTTP/2 RCE) and the rest of the
# 18 November 2026 nginx release: 1.31.9+ (mainline) or 1.30.7+ (stable).
# Upgrades nginx + its nginx.org modules only when it's older than that.
# Fails the build (the running container is left alone) if it can't.
set -eu

# fixed VERSION -> true if it has the fixes
fixed() {
    case "$1" in
        1.30.*) [ "${1##*.}" -ge 7 ] ;;
        *) [ "$(printf '%s\n%s\n' 1.31.9 "$1" | sort -V | head -n 1)" = 1.31.9 ] ;;
    esac
}
nginx_version() { nginx -v 2>&1 | sed -n 's#.*nginx/\([0-9][0-9.]*\).*#\1#p'; }

v=$(nginx_version)
[ -n "$v" ] || { echo "patch-nginx: can't read the nginx version" >&2; exit 1; }
if fixed "$v"; then
    echo "patch-nginx: nginx $v already has the November 2026 fixes"
    exit 0
fi

echo "patch-nginx: nginx $v is affected (CVE-2026-123007 / CVE-2026-123633) — upgrading from nginx.org"
pkgs=$(dpkg-query -W -f='${db:Status-Abbrev} ${Package}\n' 'nginx' 'nginx-module-*' 2>/dev/null | awk '$1 == "ii" { print $2 }')
[ -n "$pkgs" ] || { echo "patch-nginx: no nginx packages found to upgrade" >&2; exit 1; }
export DEBIAN_FRONTEND=noninteractive
# The official nginx image doesn't keep nginx.org's package repository after
# building, so apt only sees Debian's repos. Add nginx.org's repo for this
# branch (mainline for 1.odd.x, stable for 1.even.x) and Debian release,
# signed with nginx.org's key, fetched over HTTPS from nginx.org.
if ! grep -rqs 'nginx.org/packages' /etc/apt/sources.list /etc/apt/sources.list.d/; then
    minor=$(echo "$v" | cut -d. -f2)
    if [ $((minor % 2)) -eq 1 ]; then branch=mainline/; else branch=; fi
    codename=$(. /etc/os-release && echo "$VERSION_CODENAME")
    [ -n "$codename" ] || { echo "patch-nginx: can't tell the Debian release" >&2; exit 1; }
    mkdir -p /usr/share/keyrings
    wget -q -O /usr/share/keyrings/nginx-org-signing.asc https://nginx.org/keys/nginx_signing.key \
        || { echo "patch-nginx: couldn't download nginx.org's signing key" >&2; exit 1; }
    echo "deb [signed-by=/usr/share/keyrings/nginx-org-signing.asc] https://nginx.org/packages/${branch}debian/ $codename nginx" \
        > /etc/apt/sources.list.d/nginx-org.list
    echo "patch-nginx: added nginx.org's ${branch:-stable/}debian $codename repository"
fi
apt-get update
# nginx and its modules together (modules require the exact same version)
apt-get install -y --no-install-recommends --only-upgrade $pkgs
rm -rf /var/lib/apt/lists/*

v=$(nginx_version)
if ! fixed "$v"; then
    echo "patch-nginx: still nginx $v after the upgrade — nginx.org has no fixed version for this Debian release / branch yet." >&2
    echo "patch-nginx: until it does, turn HTTP/2 off in your sites (http2 off;) — see README." >&2
    exit 1
fi
# the new binary and modules load and the image's config is valid
nginx -t
echo "patch-nginx: nginx upgraded to $v"
