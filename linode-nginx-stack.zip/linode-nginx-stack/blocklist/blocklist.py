#!/usr/bin/env python3
"""Inbound blocklist for this host: drops NEW connections arriving on the
public interface from networks on trusted "drop all traffic from these"
lists, before they reach nginx (Minecraft/frp stream ports, websites),
frps, frps-voip, SSH or anything else listening here.

Why the kernel (nftables), not nginx: players' packets carry their real IP
only here on the Linode, and dropping them in the kernel costs one set
lookup per NEW connection — established traffic is never looked at, and
nothing reaches userspace. It also covers services that don't go through
nginx (frps-voip's direct UDP ports, SSH).

Lives in its own nftables table, so it never touches the iptables rules that
SoftEther, WireGuard, Tailscale, Docker and StratumVPN manage. If anything
removes the table anyway, it is put back within BLOCKLIST_CHECK_SECONDS.

Lists (all built to contain no legitimate traffic):
  * Spamhaus DROP  — networks hijacked by or leased to criminals
  * FireHOL level1 — Spamhaus DROP + DShield top attackers + Feodo botnet
                     C2 + unallocated (bogon) space
  * EXTRA_BLOCKLIST_URLS — your own plain-text lists
Never blocked, whatever a list says: private/local/CGNAT/Tailscale ranges,
Cloudflare (read from cloudflare-realip.conf), ALLOWLIST,
FAIL2BAN_WHITELIST_IPS, RATE_LIMIT_WHITELIST_IPS, this host's own addresses
and its DNS servers.

Fail-safe: a list that fails to download, comes back empty, or shrinks by
more than BLOCKLIST_MAX_SHRINK_PERCENT keeps its previous copy. On stop the
table is removed (traffic is never blocked by a dead service).
"""
import bisect
import hmac
import ipaddress
import json
import sqlite3
import os
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

TABLE = os.environ.get("BLOCKLIST_NFT_TABLE", "linode_blocklist")
STATE = os.environ.get("STATE_DIR", "/state")
CF_CONF = os.environ.get("CLOUDFLARE_REALIP_CONF", "/nginx-conf/conf.d/cloudflare-realip.conf")
UA = "linode-blocklist/1.0 (+https://github.com/AngelGonePro/docker-compose-proxy)"

PROTECTED = [ipaddress.ip_network(n) for n in (
    "0.0.0.0/32", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16",
    "172.16.0.0/12", "192.168.0.0/16", "224.0.0.0/4", "255.255.255.255/32",
    "::/128", "::1/128", "fc00::/7", "fe80::/10", "ff00::/8", "::ffff:0:0/96")]


def env(k, d=""):
    v = os.environ.get(k, "").strip()
    return v if v else d


def env_int(k, d):
    try:
        return int(env(k, str(d)))
    except ValueError:
        return d


def env_bool(k, d):
    v = env(k, "")
    return d if v == "" else v.lower() in ("1", "true", "yes", "on")


def words(v):
    return [w for w in re.split(r"[\s,]+", v or "") if w]


def log(msg):
    print(f"[blocklist] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}", flush=True)


def net(text):
    try:
        return ipaddress.ip_network(text.strip(), strict=False)
    except ValueError:
        return None


def http_get(url, timeout=60):
    if url.startswith("file://"):
        with open(url[7:], "rb") as f:
            return f.read()
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


# ----------------------------------------------------------------- lists ---
def fetch_spamhaus():
    out = []
    for url in (env("SPAMHAUS_DROP_V4_URL", "https://www.spamhaus.org/drop/drop_v4.json"),
                env("SPAMHAUS_DROP_V6_URL", "https://www.spamhaus.org/drop/drop_v6.json")):
        for line in http_get(url).decode("utf-8", "replace").splitlines():
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if "cidr" in obj:
                out.append(obj["cidr"])
    return out


def fetch_netset(url):
    out = []
    for line in http_get(url).decode("utf-8", "replace").splitlines():
        line = line.split("#")[0].split(";")[0].strip()
        if line:
            out.append(line.split()[0])
    return out


def sources():
    s = []
    if env_bool("BLOCKLIST_SPAMHAUS", True):
        s.append(("spamhaus-drop", fetch_spamhaus))
    if env_bool("BLOCKLIST_FIREHOL_LEVEL1", True):
        u = env("FIREHOL_LEVEL1_URL",
                "https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/firehol_level1.netset")
        s.append(("firehol-level1", lambda u=u: fetch_netset(u)))
    for i, url in enumerate(words(env("EXTRA_BLOCKLIST_URLS"))):
        s.append((f"extra-{i + 1}", lambda url=url: fetch_netset(url)))
    return s


def never_block():
    nets = list(PROTECTED)
    items = words(env("ALLOWLIST")) + words(env("FAIL2BAN_WHITELIST_IPS")) + words(env("RATE_LIMIT_WHITELIST_IPS"))
    try:   # Cloudflare's edges (all proxied website traffic comes from them)
        with open(CF_CONF) as f:
            items += re.findall(r"set_real_ip_from\s+([0-9a-fA-F.:/]+)\s*;", f.read())
    except OSError:
        pass
    try:
        with open("/etc/resolv.conf") as f:
            items += [l.split()[1] for l in f if l.startswith("nameserver") and len(l.split()) > 1]
    except OSError:
        pass
    try:
        items += [a.split("/")[0] for a in re.findall(r"inet6? ([0-9a-fA-F.:]+/\d+)",
                  subprocess.run(["ip", "-o", "addr", "show"], capture_output=True, text=True).stdout)]
    except OSError:
        pass
    nets += [n for n in (net(i) for i in items) if n]
    return nets


def sanitize(entries, protect):
    keep, rejected = [], 0
    for e in entries:
        n = net(e)
        if n is None:
            continue
        if (n.version == 4 and n.prefixlen < 8) or (n.version == 6 and n.prefixlen < 16):
            rejected += 1
            continue
        if any(n.version == p.version and n.overlaps(p) for p in protect):
            rejected += 1
            continue
        keep.append(n)
    return keep, rejected


def load_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def refresh(force=False):
    """Download due lists; keep the previous copy of any list that looks wrong."""
    lists_dir = os.path.join(STATE, "lists")
    os.makedirs(lists_dir, exist_ok=True)
    meta = load_json(os.path.join(lists_dir, "meta.json"), {})
    every = max(1, env_int("BLOCKLIST_REFRESH_HOURS", 24)) * 3600
    last = meta.get("_last_attempt", 0)
    if not force and time.time() - last < (every if meta.get("_last_ok") else 1800):
        return False
    meta["_last_attempt"] = time.time()
    protect = never_block()
    changed, ok = False, True
    wanted = set()
    for name, fn in sources():
        wanted.add(name)
        path = os.path.join(lists_dir, name + ".json")
        try:
            raw = fn()
        except Exception as e:
            ok = False
            log(f"{name}: download failed ({e.__class__.__name__}: {e}) — keeping the previous copy")
            continue
        nets, rejected = sanitize(raw, protect)
        prev = meta.get(name, {}).get("count", 0)
        problem = None
        if not nets and prev:
            problem = f"came back empty (previously {prev})"
        elif prev >= 20 and len(nets) < prev * (100 - env_int("BLOCKLIST_MAX_SHRINK_PERCENT", 50)) / 100:
            problem = f"shrank from {prev} to {len(nets)} entries"
        elif len(nets) > env_int("BLOCKLIST_MAX_ENTRIES", 200000):
            problem = f"has {len(nets)} entries (over BLOCKLIST_MAX_ENTRIES)"
        if problem:
            ok = False
            log(f"{name}: update REJECTED, {problem} — keeping the previous copy")
            continue
        save_json(path, [str(n) for n in nets])
        meta[name] = {"count": len(nets), "updated": int(time.time())}
        changed = True
        log(f"{name}: {len(nets)} networks" + (f" ({rejected} entries ignored: too wide or covering a protected address)" if rejected else ""))
    for name in [k for k in meta if not k.startswith("_") and k not in wanted]:
        meta.pop(name)                     # list switched off in .env
        try:
            os.remove(os.path.join(lists_dir, name + ".json"))
        except OSError:
            pass
        changed = True
    meta["_last_ok"] = ok
    save_json(os.path.join(lists_dir, "meta.json"), meta)
    return changed


# -------------------------------------------------------------- nftables ---
def wan_interfaces():
    configured = words(env("BLOCKLIST_INTERFACES"))
    if configured:
        return configured
    found = []
    for fam in ("-4", "-6"):
        out = subprocess.run(["ip", fam, "route", "show", "default"], capture_output=True, text=True).stdout
        for m in re.finditer(r"\bdev (\S+)", out):
            if m.group(1) not in found:
                found.append(m.group(1))
    return found


def ruleset():
    lists_dir = os.path.join(STATE, "lists")
    protect = never_block()            # re-checked at apply time too (allowlist edits)
    v4, v6 = [], []
    for name, _ in sources():
        for e in load_json(os.path.join(lists_dir, name + ".json"), []):
            n = net(e)
            if n and not any(n.version == p.version and n.overlaps(p) for p in protect):
                (v4 if n.version == 4 else v6).append(n)
    v4 = [str(n) for n in ipaddress.collapse_addresses(v4)]
    v6 = [str(n) for n in ipaddress.collapse_addresses(v6)]
    ifs = wan_interfaces()
    if not ifs:
        raise RuntimeError("could not detect the public interface — set BLOCKLIST_INTERFACES in .env")
    ifset = "{ " + ", ".join(f'"{i}"' for i in ifs) + " }"

    def iset(name, typ, elems):
        e = f" elements = {{ {', '.join(elems)} }}" if elems else ""
        # "typeof", not "type": sets of a plain "type ipv4_addr" written by a
        # newer nft make Debian 12's nft 1.0.6 crash on "nft list ruleset".
        return f"  set {name} {{ typeof {typ}; flags interval; auto-merge;{e} }}\n"

    # counter: attempts per blocked address (read by the optional stats endpoint)
    hits = ("  set hits4 { typeof ip saddr; size 65535; flags dynamic,timeout; timeout 1d; counter; }\n"
            "  set hits6 { typeof ip6 saddr; size 65535; flags dynamic,timeout; timeout 1d; counter; }\n")
    # Only NEW connections from the public interface are looked at; replies to
    # this host's own connections and established traffic skip straight past.
    rule = (f"    ct state new iifname {ifset} ip saddr @bl4 update @hits4 {{ ip saddr }} drop\n"
            f"    ct state new iifname {ifset} ip6 saddr @bl6 update @hits6 {{ ip6 saddr }} drop\n")
    text = (f"table inet {TABLE} {{}}\ndelete table inet {TABLE}\ntable inet {TABLE} {{\n"
            + iset("bl4", "ip saddr", v4) + iset("bl6", "ip6 saddr", v6) + hits
            + "  chain input { type filter hook input priority -5; policy accept;\n" + rule + "  }\n"
            + "  chain forward { type filter hook forward priority -5; policy accept;\n" + rule + "  }\n"
            + "}\n")
    return text, len(v4) + len(v6), ifs


def nft(args, stdin=None):
    return subprocess.run(["nft"] + args, input=stdin, capture_output=True, text=True)


def apply():
    text, count, ifs = ruleset()
    r = nft(["-f", "-"], text)
    if r.returncode != 0:
        log(f"could not load the nftables rules: {r.stderr.strip()[:300]}")
        return False
    log(f"active — dropping new connections from {count} networks on {', '.join(ifs)}")
    return True


def table_present():
    r = nft(["list", "chain", "inet", TABLE, "input"])
    return r.returncode == 0 and "@bl4" in r.stdout


def report(seen):
    """Log each blocked source once a day (the hit set itself expires after 1d)."""
    new = []
    for s in ("hits4", "hits6"):
        r = nft(["-j", "list", "set", "inet", TABLE, s])
        if r.returncode != 0:
            continue
        try:
            items = json.loads(r.stdout).get("nftables", [])
        except ValueError:
            continue
        for it in items:
            for el in (it.get("set") or {}).get("elem", []) or []:
                ip = el if isinstance(el, str) else (el.get("elem") or {}).get("val")
                if isinstance(ip, str) and ip not in seen:
                    seen[ip] = time.time()
                    new.append(ip)
    cutoff = time.time() - 86400
    for ip in [k for k, t in seen.items() if t < cutoff]:
        seen.pop(ip)
    if new:
        shown = ", ".join(new[:20]) + (f" (+{len(new) - 20} more)" if len(new) > 20 else "")
        log(f"blocked {len(new)} new source(s): {shown}")


def hit_counts():
    """[(ip, attempts)] from the kernel's hit sets — kept in memory only."""
    out = []
    for s in ("hits4", "hits6"):
        r = nft(["-j", "list", "set", "inet", TABLE, s])
        if r.returncode != 0:
            continue
        try:
            items = json.loads(r.stdout).get("nftables", [])
        except ValueError:
            continue
        for it in items:
            for el in (it.get("set") or {}).get("elem", []) or []:
                body = el.get("elem", el) if isinstance(el, dict) else {"val": el}
                ip = body.get("val")
                if isinstance(ip, str):
                    out.append((ip, int((body.get("counter") or {}).get("packets") or 0)))
    return out


F2B_WINDOW = 36 * 3600     # bans newer than this are reported (home's collector
                            # remembers what it has counted for 48 h)


def fail2ban_bans():
    """Recent fail2ban bans for the home threat map, read-only from fail2ban's
    own database (BLOCKLIST_FAIL2BAN_DB). One entry per ban: the address, how
    many failures led to it, the jail, and when — 't' lets home count each
    ban exactly once however often it asks."""
    path = env("BLOCKLIST_FAIL2BAN_DB", "/fail2ban-db/fail2ban.sqlite3")
    if not os.path.isfile(path):
        return []
    try:
        db = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)
        try:
            rows = db.execute("SELECT jail, ip, timeofban, data FROM bans WHERE timeofban >= ? "
                              "ORDER BY timeofban DESC LIMIT 20000",
                              (int(time.time()) - F2B_WINDOW,)).fetchall()
        finally:
            db.close()
    except sqlite3.Error:
        return []                  # fail2ban busy writing, or an older schema: try next time
    out = []
    for jail, ip, t, data in rows:
        try:
            ip = str(ipaddress.ip_address(str(ip)))
        except ValueError:
            continue
        n = 1
        try:
            if isinstance(data, (bytes, bytearray)):      # fail2ban stores it as a JSON blob
                data = data.decode("utf-8", "replace")
            n = max(1, int((json.loads(data) if isinstance(data, str) else data or {}).get("failures") or 1))
        except (ValueError, TypeError, AttributeError):
            pass
        out.append({"ip": ip, "packets": n, "list": f"fail2ban {jail}"[:80], "t": int(t)})
    return out


class ListIndex:
    """Which list an address is on, for labelling (bisect over sorted ranges)."""
    def __init__(self):
        self.idx = {}

    def load(self):
        idx = {}
        for name, _ in sources():
            for v in (4, 6):
                rng = []
                for e in load_json(os.path.join(STATE, "lists", name + ".json"), []):
                    n = net(e)
                    if n and n.version == v:
                        rng.append((int(n.network_address), int(n.broadcast_address)))
                rng.sort()
                idx[(name, v)] = ([a for a, _ in rng], [b for _, b in rng])
        self.idx = idx

    def which(self, ip):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            return ""
        x = int(a)
        for (name, v), (starts, ends) in self.idx.items():
            if v != a.version:
                continue
            i = bisect.bisect_right(starts, x) - 1
            if i >= 0 and ends[i] >= x:
                return name
        return ""


LISTS = ListIndex()


def stats_server():
    """Optional read-only stats for the home dashboard (BLOCKLIST_STATS_LISTEN).
    One GET path, a token, and an allowed-source list; it can't change anything,
    and nothing is written to disk — counts live only in the kernel set."""
    listen = env("BLOCKLIST_STATS_LISTEN")
    token = env("BLOCKLIST_STATS_TOKEN")
    if not listen:
        return
    if len(token) < 16:
        log("stats endpoint NOT started: BLOCKLIST_STATS_TOKEN must be at least 16 characters")
        return
    allow = [n for n in (net(a) for a in words(env("BLOCKLIST_STATS_ALLOW", "10.13.13.0/24"))) if n]
    host, _, port = listen.rpartition(":")

    class H(BaseHTTPRequestHandler):
        server_version = "stats"
        sys_version = ""
        timeout = 10

        def log_message(self, *a):
            pass

        def _reply(self, code, body=b""):
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            try:
                src = ipaddress.ip_address(self.client_address[0])
            except ValueError:
                return self._reply(403)
            if not any(src in n for n in allow):
                return self._reply(403)
            if self.path.split("?", 1)[0] != "/stats":
                return self._reply(404)
            got = (self.headers.get("Authorization") or "")[7:]
            if not hmac.compare_digest(got.encode(), token.encode()):
                return self._reply(401)
            hits = [{"ip": ip, "packets": n, "list": LISTS.which(ip)} for ip, n in hit_counts()]
            hits += fail2ban_bans()
            self._reply(200, json.dumps({"generated": int(time.time()), "hits": hits}).encode())

        def _deny(self):
            self._reply(405)

        do_POST = do_PUT = do_DELETE = do_PATCH = do_HEAD = do_OPTIONS = _deny

    def run():
        while True:
            try:
                srv = ThreadingHTTPServer((host.strip("[]"), int(port)), H)
                srv.daemon_threads = True
                log(f"stats endpoint listening on {listen} (allowed: {', '.join(map(str, allow))})")
                srv.serve_forever()
            except OSError as e:
                log(f"stats endpoint can't listen on {listen} yet ({e.strerror}) — retrying in 60 s")
                time.sleep(60)
    threading.Thread(target=run, daemon=True).start()


def remove():
    nft(["delete", "table", "inet", TABLE])


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "status":
        meta = load_json(os.path.join(STATE, "lists", "meta.json"), {})
        print(json.dumps({k: v for k, v in meta.items() if not k.startswith("_")}, indent=2))
        r = nft(["list", "table", "inet", TABLE])
        print("table loaded" if r.returncode == 0 else "table NOT loaded")
        return
    stop = {"now": False}

    def on_term(*_):
        stop["now"] = True
    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)

    os.makedirs(STATE, exist_ok=True)
    interval = max(10, env_int("BLOCKLIST_CHECK_SECONDS", 60))
    # Lists are cached in STATE_DIR: a restart reuses them and only downloads
    # what is due (Spamhaus asks for no more than one download a day).
    refresh()
    apply()
    LISTS.load()
    stats_server()
    seen = {}
    try:
        while not stop["now"]:
            for _ in range(interval):
                if stop["now"]:
                    break
                time.sleep(1)
            if stop["now"]:
                break
            if refresh():
                apply()
                LISTS.load()
            elif not table_present():
                log("the blocklist table was removed by something else on this host — restoring it")
                apply()
            report(seen)
    finally:
        remove()
        log("stopped — blocklist removed (nothing is blocked while this service is down)")


if __name__ == "__main__":
    main()
