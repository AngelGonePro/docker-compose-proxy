#!/bin/sh
# Runs once before nginx-ui ever starts (see docker-compose.yml's
# depends_on: condition: service_completed_successfully). nginx-ui's own
# image only seeds nginx.conf/mime.types/etc. into /etc/nginx when that
# directory is COMPLETELY empty on boot. If it's non-empty but missing
# nginx.conf specifically — a half-broken state, e.g. from a prior crash
# mid-write — it silently skips seeding and nginx never starts, with
# nothing about nginx-ui's own API/panel indicating anything is wrong.
# This detects exactly that state and clears it, so nginx-ui's real seed
# logic runs correctly on its next start.
set -eu

if [ "$(ls -A /etc/nginx 2>/dev/null)" != "" ] && [ ! -f /etc/nginx/nginx.conf ]; then
  echo "[preflight] /etc/nginx is non-empty but nginx.conf is missing (half-seeded state) — clearing so nginx-ui reseeds it properly."
  cd /etc/nginx
  rm -rf ./* 2>/dev/null || true
  rm -rf ./.[!.]* 2>/dev/null || true
else
  echo "[preflight] /etc/nginx looks fine (either properly seeded already, or genuinely empty for first boot) — nothing to do."
fi
