#!/bin/sh
# Rate-limits new connections per source IP on the ports listed in
# RATE_LIMIT_PORTS (.env) — protects raw TCP/UDP services tunneled through
# frps (e.g. Minecraft) from connection-flood DDoS. This is separate from
# fail2ban, which only ever sees HTTP access logs and has no visibility
# into non-HTTP traffic like a Minecraft protocol flood.
#
# Uses its own dedicated chain/table (never touches the host's existing
# INPUT policy or any other rules) and reuses FAIL2BAN_WHITELIST_IPS
# (space-separated, same as fail2ban's own ignoreip) so trusted IPs bypass
# the limit entirely. Tries iptables first, falls back to nftables if
# iptables isn't usable on this host — verified against a real kernel
# netfilter state during development, not just written from memory.
set -eu

CHAIN_NAME="RATELIMIT_FRP"
NFT_TABLE="ratelimit_frp"

if [ -z "${RATE_LIMIT_PORTS:-}" ]; then
  echo "[ratelimit] RATE_LIMIT_PORTS is empty — rate limiting disabled, nothing to do."
  tail -f /dev/null
fi

RATE="${RATE_LIMIT_CONN_PER_MIN:-60}/min"
BURST="${RATE_LIMIT_BURST:-20}"

# iptables is usable if the binary exists AND the kernel actually accepts
# a real rule (the binary can be present even if xtables kernel support
# isn't, e.g. some minimal/hardened hosts) — -C on a rule that doesn't
# exist returns 1 (not found) on a working setup, vs an error message on
# a genuinely broken one, so try adding and immediately removing a no-op
# rule as the real test.
iptables_usable() {
  command -v iptables >/dev/null 2>&1 || return 1
  iptables -N RATELIMIT_FRP_PROBE >/dev/null 2>&1 || return 1
  iptables -X RATELIMIT_FRP_PROBE >/dev/null 2>&1 || true
  return 0
}

apply_iptables() {
  echo "[ratelimit] using iptables backend"

  # Idempotent: tear down any previous run's rules before reapplying, so
  # restarts (including host reboots via restart:unless-stopped) don't
  # stack duplicate rules.
  iptables -D INPUT -j "$CHAIN_NAME" 2>/dev/null || true
  iptables -F "$CHAIN_NAME" 2>/dev/null || true
  iptables -X "$CHAIN_NAME" 2>/dev/null || true
  iptables -N "$CHAIN_NAME"

  for ip in ${FAIL2BAN_WHITELIST_IPS:-}; do
    echo "[ratelimit] whitelisting $ip"
    iptables -A "$CHAIN_NAME" -s "$ip" -j RETURN
  done

  OLD_IFS=$IFS
  IFS=','
  for entry in $RATE_LIMIT_PORTS; do
    IFS=$OLD_IFS
    port=$(echo "$entry" | cut -d/ -f1 | tr -d ' ')
    proto=$(echo "$entry" | cut -d/ -f2 | tr -d ' ')
    [ -z "$proto" ] && proto="tcp"
    echo "[ratelimit] rate-limiting new connections on $port/$proto to $RATE (burst $BURST)"
    iptables -A "$CHAIN_NAME" -p "$proto" --dport "$port" -m conntrack --ctstate NEW \
      -m hashlimit --hashlimit-name "rl_${port}_${proto}" --hashlimit-mode srcip \
      --hashlimit-upto "$RATE" --hashlimit-burst "$BURST" -j RETURN
    iptables -A "$CHAIN_NAME" -p "$proto" --dport "$port" -m conntrack --ctstate NEW -j DROP
    IFS=','
  done
  IFS=$OLD_IFS

  iptables -I INPUT -j "$CHAIN_NAME"
  echo "[ratelimit] iptables rules applied."
}

apply_nftables() {
  echo "[ratelimit] using nftables backend (iptables not usable on this host)"

  nft delete table inet "$NFT_TABLE" 2>/dev/null || true

  RULESET_FILE="/tmp/ratelimit.nft"
  {
    echo "table inet $NFT_TABLE {"
    echo "  set whitelist {"
    echo "    type ipv4_addr"
    echo "    flags interval"
    if [ -n "${FAIL2BAN_WHITELIST_IPS:-}" ]; then
      elements=$(echo "$FAIL2BAN_WHITELIST_IPS" | tr -s ' ' ',' | sed 's/,$//; s/^,//')
      echo "    elements = { $elements }"
    fi
    echo "  }"

    OLD_IFS=$IFS
    IFS=','
    for entry in $RATE_LIMIT_PORTS; do
      IFS=$OLD_IFS
      port=$(echo "$entry" | cut -d/ -f1 | tr -d ' ')
      proto=$(echo "$entry" | cut -d/ -f2 | tr -d ' ')
      [ -z "$proto" ] && proto="tcp"
      setname="mc_${port}_${proto}"
      echo "  set $setname {"
      echo "    type ipv4_addr"
      echo "    timeout 60s"
      echo "    flags dynamic"
      echo "  }"
      IFS=','
    done
    IFS=$OLD_IFS

    echo "  chain input {"
    echo "    type filter hook input priority filter - 5; policy accept;"
    echo "    ip saddr @whitelist accept"

    OLD_IFS=$IFS
    IFS=','
    for entry in $RATE_LIMIT_PORTS; do
      IFS=$OLD_IFS
      port=$(echo "$entry" | cut -d/ -f1 | tr -d ' ')
      proto=$(echo "$entry" | cut -d/ -f2 | tr -d ' ')
      [ -z "$proto" ] && proto="tcp"
      setname="mc_${port}_${proto}"
      echo "    $proto dport $port ct state new update @$setname { ip saddr limit rate ${RATE_LIMIT_CONN_PER_MIN:-60}/minute burst $BURST packets } accept"
      echo "    $proto dport $port ct state new drop"
      IFS=','
    done
    IFS=$OLD_IFS

    echo "  }"
    echo "}"
  } > "$RULESET_FILE"

  nft -f "$RULESET_FILE"
  echo "[ratelimit] nftables rules applied."
}

if iptables_usable; then
  apply_iptables
elif command -v nft >/dev/null 2>&1; then
  apply_nftables
else
  echo "[ratelimit] Neither iptables nor nftables is usable on this host — rate limiting NOT applied. This does not block the rest of the stack, but Minecraft/etc. traffic through frps has no DDoS protection until this is resolved." >&2
fi

tail -f /dev/null
