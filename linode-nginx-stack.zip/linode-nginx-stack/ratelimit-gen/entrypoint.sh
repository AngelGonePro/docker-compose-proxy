#!/bin/sh
set -eu

OUT="/nginx-conf-shared/streams-enabled/ratelimit.conf"
# The change-detection snapshot must NEVER live inside streams-enabled/
# itself — nginx's include pattern there has no file extension filter
# (streams-enabled/*), so a .prev file sitting alongside the real one
# gets parsed too, producing a duplicate limit_conn_zone name and a
# hard config error that silently breaks every reload from that point
# forward (confirmed the hard way: nothing in the stream block applied
# at all once this file existed, for exactly this reason).
STATE_DIR="/nginx-conf-shared/.ratelimit-gen-state"
PREV="$STATE_DIR/ratelimit.conf.prev"
mkdir -p "$(dirname "$OUT")" "$STATE_DIR"

API_BASE="http://127.0.0.1:${FRP_DASHBOARD_PORT}"
API_AUTH="${FRP_DASHBOARD_USER}:${FRP_DASHBOARD_PASSWORD}"

is_excluded() {
  port="$1"
  for p in ${RATE_LIMIT_EXCLUDE_PORTS:-}; do
    [ "$p" = "$port" ] && return 0
  done
  return 1
}

# --- .env rate-limit settings (all optional; empty = off) -------------
# RATE_LIMIT_PORTS="25565 25566/tcp"  new connections per minute per IP
#   on these ports, RATE_LIMIT_CONN_PER_MIN with a RATE_LIMIT_BURST
#   allowance. Commas or spaces; /tcp optional. TCP only: nginx counts
#   every UDP datagram as its own session, so a per-minute limit there
#   would cut off game traffic — /udp entries are skipped with a warning.
# RATE_LIMIT_RULES="25565:25501:tcp:5,19132:19501:udp:3"
#   public_port:internal_port:protocol:max_concurrent_per_ip. For a port
#   frps already tunnels, overrides RATE_LIMIT_MAX_CONN for that port;
#   for one it doesn't, the port is served from the rule as written.
# RATE_LIMIT_PROXY_PROTOCOL_PORTS="25565 19132"  send the PROXY header
#   (real client IP) on these public ports, in addition to any proxy
#   whose name ends in -realip.
# Done inside nginx (stream module + nginx's own njs module, both part of
# the nginx-ui image) — no iptables/nftables, so OS upgrades don't touch it.
#
# IPv6: one home connection gets a whole /64 and can hop between addresses
# in it, so every limit here (connections at once and per minute) counts an
# IPv6 client by its /64 — the same block fail2ban bans (F2B_IPV6_BAN_PREFIX).
# That needs njs too; without it (module missing) limits fall back to per
# address and everything else still works.
NJS_FILE="/nginx-conf-shared/njs/ratelimit-gen.js"
NGINX_CONF="/nginx-conf-shared/nginx.conf"
JS_MODULE="/usr/lib/nginx/modules/ngx_stream_js_module.so"

list_items() { echo "${1:-}" | tr ',' ' '; }

in_list() {
  # $1 = port, $2 = list of ports
  for p in $(list_items "$2"); do
    [ "$p" = "$1" ] && return 0
  done
  return 1
}

# per-minute ports (TCP)
is_rate_port() {
  for e in $(list_items "${RATE_LIMIT_PORTS:-}"); do
    port="${e%%/*}"
    case "$e" in */*) pr="${e#*/}" ;; *) pr=tcp ;; esac
    [ "$port" = "$1" ] && [ "$pr" = tcp ] && return 0
  done
  return 1
}

warn_udp_rate_ports() {
  for e in $(list_items "${RATE_LIMIT_PORTS:-}"); do
    case "$e" in */udp) echo "[ratelimit-gen] RATE_LIMIT_PORTS: skipping '$e' — per-minute limiting is TCP only (nginx treats each UDP datagram as its own session). UDP still gets RATE_LIMIT_MAX_CONN / RATE_LIMIT_RULES." >&2 ;; esac
  done
}

# RATE_LIMIT_RULES lookup: $1 = public port, $2 = proto -> prints "internal max"
rule_for() {
  for r in $(list_items "${RATE_LIMIT_RULES:-}"); do
    IFS=: read -r rp ri rproto rmax <<EOF_RULE
$r
EOF_RULE
    [ -z "$rproto" ] && rproto=tcp
    if [ "$rp" = "$1" ] && [ "$rproto" = "$2" ]; then
      echo "$ri ${rmax:-${RATE_LIMIT_MAX_CONN:-3}}"
      return 0
    fi
  done
  return 1
}

needs_proxy_protocol() {
  # $1 = public port, $2 = 1 if the frpc name ends in -realip
  [ "$2" = 1 ] && return 0
  in_list "$1" "${RATE_LIMIT_PROXY_PROTOCOL_PORTS:-}"
}

# public ports frps currently tunnels for one proto ($1 = lines)
discovered_ports() {
  echo "$1" | while IFS='|' read -r name internal_port; do
    [ -z "$name" ] && continue
    n="${name%-realip}"
    echo "$n" | grep -oE '[0-9]+$' || true
  done
}

# Per-minute limiting needs nginx's stream js module loaded. It's in the
# nginx-ui image but not loaded by its default nginx.conf, so add one
# load_module line (after any existing ones) if it's missing. Never
# touches anything else in nginx.conf; if the module isn't in the image,
# per-minute limiting is skipped (logged) and everything else still works.
JS_READY=0
ensure_js_module() {
  JS_READY=0
  if ! docker exec nginx-ui test -f "$JS_MODULE" 2>/dev/null; then
    if [ "${JS_MISSING_LOGGED:-0}" -eq 0 ]; then
      echo "[ratelimit-gen] ERROR: $JS_MODULE isn't in the nginx-ui image — RATE_LIMIT_PORTS per-minute limiting is OFF and IPv6 clients are limited per address instead of per /64 until it is. Everything else still applies." >&2
      JS_MISSING_LOGGED=1
    fi
    return 0
  fi
  [ -f "$NGINX_CONF" ] || return 0
  if ! grep -q 'ngx_stream_js_module' "$NGINX_CONF"; then
    last=$(grep -n '^[[:space:]]*load_module' "$NGINX_CONF" | tail -n 1 | cut -d: -f1)
    tmp="$NGINX_CONF.ratelimit-gen.tmp"
    if [ -n "$last" ]; then
      awk -v n="$last" -v m="$JS_MODULE" '{ print } NR == n { print "load_module " m "; # added by ratelimit-gen (rate limits)" }' "$NGINX_CONF" > "$tmp"
    else
      { echo "load_module $JS_MODULE; # added by ratelimit-gen (rate limits)"; cat "$NGINX_CONF"; } > "$tmp"
    fi
    cat "$tmp" > "$NGINX_CONF" && rm -f "$tmp"
    echo "[ratelimit-gen] added 'load_module $JS_MODULE;' to nginx.conf (needed for IPv6 /64 limits and RATE_LIMIT_PORTS)."
  fi
  # token bucket per IP per port: RATE_LIMIT_BURST connections at once,
  # refilling at RATE_LIMIT_CONN_PER_MIN per minute
  rate="${RATE_LIMIT_CONN_PER_MIN:-60}"
  burst="${RATE_LIMIT_BURST:-20}"
  case "$rate" in ''|*[!0-9]*) echo "[ratelimit-gen] RATE_LIMIT_CONN_PER_MIN='$rate' isn't a whole number — using 60." >&2; rate=60 ;; esac
  case "$burst" in ''|*[!0-9]*) echo "[ratelimit-gen] RATE_LIMIT_BURST='$burst' isn't a whole number — using 20." >&2; burst=20 ;; esac
  [ "$burst" -ge 1 ] || burst=1
  mkdir -p "$(dirname "$NJS_FILE")"
  cat > "$NJS_FILE.tmp" <<EOF_JS
// Auto-generated by ratelimit-gen from RATE_LIMIT_CONN_PER_MIN /
// RATE_LIMIT_BURST in .env — do not edit by hand.
var RATE = ${rate};   // new connections per minute per IP, per port
var BURST = ${burst};  // allowed at once before the per-minute rate applies

// IPv6 address -> its /64 ("2001:db8:0:1::/64"); IPv4 (incl. IPv4-mapped) unchanged
function block64(a) {
    var pct = a.indexOf('%');
    if (pct >= 0) { a = a.slice(0, pct); }
    if (a.indexOf(':') < 0) { return a; }
    if (a.indexOf('.') >= 0) {
        var last = a.lastIndexOf(':');
        if (/^::ffff:/i.test(a)) { return a.slice(last + 1); }
        a = a.slice(0, last + 1) + '0:0';
    }
    var halves = a.split('::');
    var head = halves[0] ? halves[0].split(':') : [];
    var full = head;
    if (halves.length > 1) {
        var tail = halves[1] ? halves[1].split(':') : [];
        for (var i = head.length + tail.length; i < 8; i++) { full.push('0'); }
        full = full.concat(tail);
    }
    var out = [];
    for (var j = 0; j < 4; j++) { out.push(parseInt(full[j] || '0', 16).toString(16)); }
    return out.join(':') + '::/64';
}

// \$ratelimit_key: "" for RATE_LIMIT_WHITELIST_IPS (never limited), else the
// client's IPv4 address or IPv6 /64
function key(s) {
    if (s.variables.ratelimit_whitelisted === '1') { return ''; }
    return block64(s.remoteAddress);
}

function access(s) {
    var k = s.variables.ratelimit_key;
    // decline = "no objection": nginx still runs its other access checks
    // (the fail2ban stream deny list). allow() would skip them.
    if (k === '') { s.decline(); return; }
    var d = ngx.shared.ratelimit_per_min;
    var key = s.variables.server_port + ' ' + k;
    var now = Date.now();
    var tokens = BURST;
    var v = d.get(key);
    if (v) {
        var p = v.split(' ');
        tokens = Math.min(BURST, Number(p[0]) + (now - Number(p[1])) * RATE / 60000);
    }
    if (tokens < 1) {
        d.set(key, tokens + ' ' + now);
        s.warn('ratelimit-gen: ' + s.remoteAddress + ' over ' + RATE + '/min (burst ' + BURST + ') on port ' + s.variables.server_port + ' - connection refused');
        s.deny();
        return;
    }
    d.set(key, (tokens - 1) + ' ' + now);
    s.decline();
}

export default { key, access };
EOF_JS
  mv "$NJS_FILE.tmp" "$NJS_FILE"
  JS_READY=1
}

fetch_proxies() {
  proto="$1"
  resp=$(curl -fsS -u "$API_AUTH" "$API_BASE/api/proxy/$proto" 2>/tmp/frps_api_err.log) || {
    echo "[ratelimit-gen] Failed to reach frps dashboard API for $proto proxies: $(cat /tmp/frps_api_err.log)" >&2
    return 1
  }
  echo "$resp" | jq -r '.proxies[]? | select(.status == "online") | "\(.name)|\(.conf.remotePort)"' 2>/tmp/frps_jq_err.log || {
    echo "[ratelimit-gen] Failed to parse frps API response for $proto proxies (unexpected shape): $(cat /tmp/frps_jq_err.log)" >&2
    echo "[ratelimit-gen] Raw response was: $resp" >&2
    return 1
  }
}

process_rules() {
  tcp_found=$(discovered_ports "$TCP_LINES")
  udp_found=$(discovered_ports "$UDP_LINES")
  for r in $(list_items "${RATE_LIMIT_RULES:-}"); do
    IFS=: read -r rp ri rproto rmax <<EOF_RULE
$r
EOF_RULE
    [ -z "$rproto" ] && rproto=tcp
    case "$rp:$ri" in *[!0-9:]*|:*|*:) echo "[ratelimit-gen] RATE_LIMIT_RULES: skipping '$r' — format is public_port:internal_port:protocol:max_concurrent_per_ip" >&2; continue ;; esac
    if [ "$rproto" = tcp ]; then found="$tcp_found"; else found="$udp_found"; fi
    in_list "$rp" "$found" && continue   # tunneled by frps: handled above
    zone="rl_${rp}_${rproto}"
    echo "limit_conn_zone \$ratelimit_key zone=${zone}:10m;"
    echo "server {"
    if [ "$rproto" = "udp" ]; then
      echo "    listen ${rp} udp;"
      echo "    listen [::]:${rp} udp;"
      echo "    proxy_responses 0;"
      echo "    proxy_timeout 30s;"
    else
      echo "    listen ${rp};"
      echo "    listen [::]:${rp};"
      echo "    proxy_timeout 10m;"
      echo "    proxy_connect_timeout 5s;"
    fi
    if needs_proxy_protocol "$rp" 0; then
      echo "    proxy_protocol on;"
    fi
    if [ "$rproto" = "tcp" ] && [ "$JS_READY" -eq 1 ] && is_rate_port "$rp"; then
      echo "    js_access ratelimit_js.access;"
    fi
    echo "    proxy_pass 127.0.0.1:${ri};"
    echo "    limit_conn ${zone} ${rmax:-${RATE_LIMIT_MAX_CONN:-3}};"
    echo "}"
    echo ""
  done
}

generate() {
  FETCH_OK=1
  TCP_LINES=$(fetch_proxies tcp) || FETCH_OK=0
  UDP_LINES=$(fetch_proxies udp) || FETCH_OK=0

  ensure_js_module

  if [ "$FETCH_OK" -eq 0 ]; then
    if [ -f "$OUT" ]; then
      echo "[ratelimit-gen] frps API fetch failed — keeping the last-known-good config in place rather than blanking it out. Will retry next cycle." >&2
      return 1
    fi
    echo "[ratelimit-gen] frps API fetch failed and there's no existing config to fall back to — generating a minimal one with no rate-limited ports until the API is reachable." >&2
  fi

  {
    echo "# Auto-generated by ratelimit-gen from frps's own active proxy list"
    echo "# (via its dashboard API) and RATE_LIMIT_EXCLUDE_PORTS /"
    echo "# RATE_LIMIT_WHITELIST_IPS in .env — do not edit by hand."
    echo ""

    if [ "$JS_READY" -eq 1 ]; then
      echo "geo \$remote_addr \$ratelimit_whitelisted {"
      echo "    default 0;"
      for ip in ${RATE_LIMIT_WHITELIST_IPS:-}; do
        echo "    ${ip} 1;"
      done
      echo "}"
      echo "js_import ratelimit_js from $(echo "$NJS_FILE" | sed 's#^/nginx-conf-shared#/etc/nginx#');"
      echo "# IPv4 address, or IPv6 /64; empty (not limited) for RATE_LIMIT_WHITELIST_IPS"
      echo "js_set \$ratelimit_key ratelimit_js.key;"
    elif [ -n "${RATE_LIMIT_WHITELIST_IPS:-}" ]; then
      # geo matches the client's address ($remote_addr) and can only hold
      # fixed values, so it marks whitelisted IPs and map turns that into
      # the limit key: "" (never limited) for them, their own address for
      # everyone else. (geo on $binary_remote_addr never matched anything
      # and gave every client the same literal key.)
      echo "geo \$remote_addr \$ratelimit_whitelisted {"
      echo "    default 0;"
      for ip in $RATE_LIMIT_WHITELIST_IPS; do
        echo "    ${ip} 1;"
      done
      echo "}"
      echo "map \$ratelimit_whitelisted \$ratelimit_key { 1 \"\"; default \$binary_remote_addr; }"
    else
      echo "map \$binary_remote_addr \$ratelimit_key { default \$binary_remote_addr; }"
    fi
    echo ""

    if [ "$JS_READY" -eq 1 ] && [ -n "$(list_items "${RATE_LIMIT_PORTS:-}" | tr -d ' ')" ]; then
      echo "# RATE_LIMIT_PORTS: ${RATE_LIMIT_CONN_PER_MIN:-60} new connections/min per IP, burst ${RATE_LIMIT_BURST:-20}"
      echo "js_shared_dict_zone zone=ratelimit_per_min:1m timeout=1h type=string evict;"
      echo ""
    fi

process_proto() {
  proto="$1"
  lines="$2"
  [ -z "$lines" ] && return 0
  echo "$lines" | while IFS='|' read -r name internal_port; do
    [ -z "$name" ] && continue

    needs_realip=0
    parse_name="$name"
    case "$parse_name" in
      *-realip)
        needs_realip=1
        parse_name="${parse_name%-realip}"
        ;;
    esac

    public_port=$(echo "$parse_name" | grep -oE '[0-9]+$' || true)
    if [ -z "$public_port" ]; then
      echo "[ratelimit-gen] Skipping proxy '$name' — name doesn't end in -<public_port> or -<public_port>-realip (required convention)." >&2
      continue
    fi
    if [ "$public_port" = "$internal_port" ]; then
      echo "[ratelimit-gen] Skipping proxy '$name' — public port and internal remotePort are identical ($public_port); they must differ." >&2
      continue
    fi

    if is_excluded "$public_port"; then
      echo "server {"
      if [ "$proto" = "udp" ]; then
        echo "    listen ${public_port} udp;"
        echo "    listen [::]:${public_port} udp;"
        echo "    proxy_responses 0;"
        echo "    proxy_timeout 30s;"
      else
        echo "    listen ${public_port};"
        echo "    listen [::]:${public_port};"
        echo "    proxy_timeout 10m;"
        echo "    proxy_connect_timeout 5s;"
      fi
      if needs_proxy_protocol "$public_port" "$needs_realip"; then
        echo "    proxy_protocol on;"
      fi
      echo "    proxy_pass 127.0.0.1:${internal_port};"
      echo "}"
      echo ""
    else
      zone="rl_${public_port}_${proto}"
      echo "limit_conn_zone \$ratelimit_key zone=${zone}:10m;"
      echo "server {"
      if [ "$proto" = "udp" ]; then
        echo "    listen ${public_port} udp;"
        echo "    listen [::]:${public_port} udp;"
        echo "    proxy_responses 0;"
        echo "    proxy_timeout 30s;"
      else
        echo "    listen ${public_port};"
        echo "    listen [::]:${public_port};"
        echo "    proxy_timeout 10m;"
        echo "    proxy_connect_timeout 5s;"
      fi
      if needs_proxy_protocol "$public_port" "$needs_realip"; then
        echo "    proxy_protocol on;"
      fi
      if [ "$proto" = "tcp" ] && [ "$JS_READY" -eq 1 ] && is_rate_port "$public_port"; then
        echo "    js_access ratelimit_js.access;"
      fi
      echo "    proxy_pass 127.0.0.1:${internal_port};"
      max_conn="${RATE_LIMIT_MAX_CONN:-3}"
      if rule=$(rule_for "$public_port" "$proto"); then
        max_conn="${rule#* }"
      fi
      echo "    limit_conn ${zone} ${max_conn};"
      echo "}"
      echo ""
    fi
  done
}

    process_proto tcp "$TCP_LINES"
    process_proto udp "$UDP_LINES"
    process_rules
  } > "$OUT"
}

# $PREV always holds the config nginx has actually loaded — it's only
# updated after a reload that really succeeded. Before, the startup
# reload never updated it, so after a restart $PREV still held the
# config from before the restart. If the first generate at startup
# happened while a home proxy (e.g. minecraft 25565) was still
# reconnecting, nginx got reloaded without that port; a minute later
# the proxy was back, the new config matched that stale $PREV, so no
# reload happened and nginx kept running without the port — with the
# right config sitting on disk the whole time (what took 25565 down).
reload() {
  if ! out=$(docker exec nginx-ui nginx -t 2>&1); then
    echo "[ratelimit-gen] $(date -u +'%Y-%m-%dT%H:%M:%SZ') ERROR: nginx config test failed — NOT reloaded, will retry next cycle:" >&2
    echo "$out" >&2
    return 1
  fi
  if ! out=$(docker exec nginx-ui nginx -s reload 2>&1); then
    echo "[ratelimit-gen] $(date -u +'%Y-%m-%dT%H:%M:%SZ') ERROR: nginx reload failed, will retry next cycle:" >&2
    echo "$out" >&2
    return 1
  fi
  cp "$OUT" "$PREV"
  return 0
}

# Safety check: every port in the generated config must actually be
# open on this host (network_mode: host, so /proc/net is the host's).
# If one isn't — for any reason, including ones not foreseen here —
# reload nginx so it picks up the config on disk, and say so in the log.
port_open() {
  # $1 = port, $2 = tcp|udp. /proc/net lists local ports in hex; for TCP
  # only LISTEN (state 0A) counts.
  hex=$(printf '%04X' "$1")
  if [ "$2" = "tcp" ]; then
    cat /proc/net/tcp /proc/net/tcp6 2>/dev/null | awk -v p=":$hex" '$4 == "0A" && substr($2, length($2)-4) == p { f=1 } END { exit !f }'
  else
    cat /proc/net/udp /proc/net/udp6 2>/dev/null | awk -v p=":$hex" 'substr($2, length($2)-4) == p { f=1 } END { exit !f }'
  fi
}

port_open6() {
  hex=$(printf '%04X' "$1")
  if [ "$2" = "tcp" ]; then
    awk -v p=":$hex" '$4 == "0A" && substr($2, length($2)-4) == p { f=1 } END { exit !f }' /proc/net/tcp6 2>/dev/null
  else
    awk -v p=":$hex" 'substr($2, length($2)-4) == p { f=1 } END { exit !f }' /proc/net/udp6 2>/dev/null
  fi
}

missing_ports() {
  [ -f "$OUT" ] || return 0
  grep -E '^[[:space:]]*listen [0-9]+( udp)?;' "$OUT" | while read -r _ port proto; do
    port="${port%;}"
    case "$proto" in udp*) proto=udp ;; *) proto=tcp ;; esac
    port_open "$port" "$proto" || echo "$port/$proto"
  done
  # IPv6 listeners ("listen [::]:25565;") — only checked if this host has IPv6
  [ -f /proc/net/tcp6 ] || return 0
  grep -E '^[[:space:]]*listen \[::\]:[0-9]+( udp)?;' "$OUT" | while read -r _ addr proto; do
    port="${addr##*:}"; port="${port%;}"
    case "$proto" in udp*) proto=udp ;; *) proto=tcp ;; esac
    port_open6 "$port" "$proto" || echo "[::]:$port/$proto"
  done
}

verify_listening() {
  missing=$(missing_ports | tr '\n' ' ')
  [ -z "$missing" ] && return 0
  echo "[ratelimit-gen] $(date -u +'%Y-%m-%dT%H:%M:%SZ') WARNING: in the config but not open: ${missing}— reloading nginx." >&2
  if reload; then
    sleep 2
    still=$(missing_ports | tr '\n' ' ')
    if [ -n "$still" ]; then
      echo "[ratelimit-gen] $(date -u +'%Y-%m-%dT%H:%M:%SZ') ERROR: still not open after reload: ${still}— check 'docker exec nginx-ui nginx -T' and what else is using those ports." >&2
    else
      echo "[ratelimit-gen] $(date -u +'%Y-%m-%dT%H:%M:%SZ') fixed: all ports open again."
    fi
  fi
}

# On a fresh deploy (or any container restart), frps and ratelimit-gen
# start at roughly the same time — frps's dashboard often isn't bound
# yet on the very first attempt, confirmed live: this failed, correctly
# preserved the prior config, and only actually picked up the real
# proxy list once the 60s retry loop got a second chance. Rather than
# make every fresh install wait up to a minute (or worse, wonder if
# something's actually broken), retry a few times quickly at startup
# before falling back to the slower loop.
warn_udp_rate_ports

STARTUP_OK=0
for attempt in 1 2 3 4 5 6; do
  generate || true
  if [ "$FETCH_OK" -eq 1 ]; then
    STARTUP_OK=1
    break
  fi
  echo "[ratelimit-gen] Startup attempt $attempt/6: frps dashboard not reachable yet — retrying in 5s." >&2
  sleep 5
done

if [ "$STARTUP_OK" -eq 1 ]; then
  if reload; then
    echo "[ratelimit-gen] generated $OUT and reloaded nginx-ui."
  fi
else
  echo "[ratelimit-gen] Startup fetch failed after 6 attempts (30s) but an existing config was already in place — leaving it as-is and continuing to the 60s retry loop." >&2
fi

while true; do
  sleep 60
  if generate; then
    if ! diff -q "$OUT" "$PREV" >/dev/null 2>&1; then
      if reload; then
        echo "[ratelimit-gen] $(date -u +'%Y-%m-%dT%H:%M:%SZ') proxy list changed — regenerated and reloaded."
      fi
    fi
  fi
  verify_listening
done
