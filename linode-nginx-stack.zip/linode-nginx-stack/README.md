# nginx-ui + Cloudflare wildcard cert

Solves two things NPM couldn't:
- Raw nginx.conf / server block editing (nginx-ui edits real config files directly)
- One wildcard cert covering the root domain and every subdomain, issued via
  Cloudflare DNS-01 — so no port-80 HTTP-01 dance per subdomain, and no NPM
  proxying oddities in front of Nextcloud.

## Deploying an update to an existing install

Don't extract a new release zip directly over a live deployment — `.env`
is genuinely part of what's shipped (as a template), so a plain
overwrite replaces your real tokens/passwords with placeholder values.
`deploy-update.sh` handles this safely instead — tested end-to-end
against a simulated real deployment (real cert files, real nginx-ui
site configs and database, real fail2ban ban history and
auto-generated Cloudflare whitelist, a real filled-in `.env`) and
confirmed every piece of that survives untouched, while the actual
code (`docker-compose.yml`, entrypoint scripts, etc.) genuinely
updates:

```
./deploy-update.sh https://raw.githubusercontent.com/<you>/<repo>/refs/heads/main/linode-nginx-stack.zip linode-nginx-stack
```

`.env` is merged, not overwritten or left untouched: existing values
for keys you already have are kept exactly as they are, and any
genuinely new key the update adds gets appended with its default,
called out at the end of the run so you know to review it. Runtime
state (`nginx-conf/`, `nginx-ui-data/`, `certbot/certs/`,
`fail2ban/data/`, `nginx-logs/`, and the auto-generated
`00-ignoreip.local`) is never touched regardless of what's in the zip.

After it finishes: `docker compose up -d --remove-orphans` — the
`--remove-orphans` flag matters if a release removes a service that
was previously running.

## Setup

1. Edit `.env` directly and fill in `ROOT_DOMAIN`, `CF_API_TOKEN`,
   `LE_EMAIL`, and `NGINX_UI_ADMIN_EMAIL`/`NGINX_UI_ADMIN_USER`/
   `NGINX_UI_ADMIN_PASSWORD`. The Cloudflare token needs **Zone:DNS:Edit**
   scoped to just that zone — not the Global API key.

2. `docker compose up -d --build`

   `nginx-conf-preflight` runs first and checks `nginx-conf/` for a
   specific broken state (non-empty but missing `nginx.conf` — can
   happen after a crash mid-write) and clears it automatically if found,
   so nginx-ui's own first-boot seeding runs correctly. This used to be a
   manual recovery step; now it happens on every `docker compose up -d`
   with nothing to run by hand.

   Everything else happens on its own:
   - `certbot` requests the wildcard cert for `ROOT_DOMAIN`/`*.ROOT_DOMAIN`
     from Let's Encrypt, and if that fails for any reason — most commonly
     LE's "5 certs per exact domain set per 168h" limit, which is shared
     across any client requesting that domain set — automatically falls
     back to ZeroSSL (a separate CA, its own rate-limit pool, no signup
     needed, just an email). Whichever one succeeds is what gets renewed
     going forward; nothing to configure or remember either way. It keeps
     retrying every 15 minutes if both fail, rather than giving up. Then
     it checks for renewal every 12 hours. `certbot`'s own docker.sock
     mount lets it trigger `nginx -s reload` inside `nginx-ui` after a
     renewal — nginx-ui itself doesn't have docker.sock (see Security notes).
   - `bootstrap` waits for nginx-ui to come up, completes its first-run
     setup using the admin account from `.env` (or just logs in if it
     was already set up manually before), waits for certbot to actually
     issue the cert, then imports it into nginx-ui via its own API.
     Check `docker logs bootstrap` if anything looks off — it logs each
     step and exits non-zero with a clear reason on failure.

3. Certs land in `./certbot/certs/live/${ROOT_DOMAIN}/` on the host, which
   `certbot` itself sees at `/etc/letsencrypt` (its own required layout)
   and `nginx-ui` sees at `/etc/nginx/ssl/letsencrypt` — nginx-ui's cert
   import requires the path to be under its own `/etc/nginx`, so use that
   second path in every server block and in nginx-ui's own Certificates
   list, not `/etc/letsencrypt`. No per-subdomain certificate needed
   since it's a wildcard.

### Retrofitting onto an already-running install

If nginx-ui was already set up manually before `bootstrap` existed (e.g.
you clicked through the setup wizard yourself), set
`NGINX_UI_ADMIN_USER`/`NGINX_UI_ADMIN_PASSWORD` in `.env` to match the
account you actually created — `bootstrap` sees `nginx-ui` is already
locked and skips straight to logging in with those values. If you have a
broken/incomplete cert entry from a manual "Issue certificate" attempt,
delete it in the panel first (Certificates List → Delete), then:

```
docker compose up -d bootstrap
```

## Standard subdomain (e.g. share.cosmoscraft.net)

Paste this into nginx-ui's raw config editor for that site:

```nginx
server {
    listen 443 ssl;
    server_name share.cosmoscraft.net;

    ssl_certificate     /etc/nginx/ssl/letsencrypt/live/cosmoscraft.net/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/letsencrypt/live/cosmoscraft.net/privkey.pem;

    location / {
        proxy_pass http://embed-server:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

server {
    listen 80;
    server_name share.cosmoscraft.net;
    return 301 https://$host$request_uri;
}
```

## Nextcloud subdomain

This is the block NPM was mangling. Nextcloud needs a larger body size
ceiling, unbuffered proxying (so large uploads don't get held in memory or
truncated at NPM's default limits), and WebDAV-friendly headers:

```nginx
server {
    listen 443 ssl;
    server_name cloud.cosmoscraft.net;

    ssl_certificate     /etc/nginx/ssl/letsencrypt/live/cosmoscraft.net/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/letsencrypt/live/cosmoscraft.net/privkey.pem;

    client_max_body_size 0;
    client_body_timeout 3600s;

    location / {
        proxy_pass http://nextcloud-fpm-or-web:80;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_request_buffering off;
        proxy_buffering off;
        proxy_max_temp_file_size 0;

        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }
}

server {
    listen 80;
    server_name cloud.cosmoscraft.net;
    return 301 https://$host$request_uri;
}
```

Adjust the `proxy_pass` target to whatever your Nextcloud compose stack
exposes (the nginx/FPM front container, not php-fpm directly).

## Log rotation

Two separate concerns, both unbounded by default:

Every container's own stdout/stderr (`docker logs <service>`) is capped
at 10MB × 3 files per service via `logging:` in `docker-compose.yml` —
applies to all of it, including `ratelimit-gen`'s 60-second polling log
lines and `frps`'s connection logs.

nginx-ui's own `access.log`/`error.log` and certbot's log are real
files bind-mounted to the host, which `logging:` has zero effect on.
nginx-ui has a built-in rotation feature but it's off by default and
has no working `/etc/logrotate.d/nginx` config even if enabled
(confirmed straight from its source — enabling it wouldn't actually do
anything without more setup). A dedicated `logrotate` service handles
both independently instead: daily rotation capped at 50M for nginx's
logs, weekly capped at 20M for certbot's, 7 and 4 rotations kept
respectively, `copytruncate` (nginx and certbot hold their log files
open for the life of the process, so a normal rename-and-reopen
rotation would leave them writing into a now-unlinked file that never
frees disk space).

Tested for real, not just written and assumed correct: created a 63MB
file, forced a rotation cycle, and confirmed with `du` (not just a file
listing) that the actual file size on disk dropped to 0 afterward —
genuine space reclaimed on the actively-written file, not just an
apparent one.

## Fail2ban (nginx-ui log protection)

A `fail2ban` service watches nginx-ui's access/error logs (mounted out
to `./nginx-logs` on the host) and bans repeat offenders — failed auth,
bot scanning, rate-limit abuse. Bans go through nginx's own deny list
(`fail2ban/action.d/nginx-denylist.conf`) rather than iptables/nftables —
this host's firewall is already managed by SoftEther, WireGuard, and
Tailscale, and Tailscale is confirmed to silently wipe rules other tools
add there directly (the same problem the old `ratelimit` service hit).
Because of that, `fail2ban` doesn't need `network_mode: host` or
`NET_ADMIN`/`NET_RAW` at all anymore — it writes to the shared
`nginx-conf/conf.d/fail2ban-denylist.conf` file (picked up automatically
by nginx-ui's own `include conf.d/*.conf;`, confirmed straight from its
source) and execs into `nginx-ui` via `docker.sock` to reload. Tested
for real: banned an IP, confirmed `403 Forbidden` with nginx's own log
showing `"access forbidden by rule"`, then unbanned and confirmed it
went back to `200 OK`.

Jail definitions live in `./fail2ban/jail.d/nginx.local`. Ban state
persists in `./fail2ban/data` across restarts. To check active bans:

```
docker exec fail2ban fail2ban-client status nginx-http-auth
```

If you add rate limiting (`limit_req`) to any nginx-ui server blocks
later, the `nginx-limit-req` jail will already pick up those log lines.

## Connection rate limiting for FRP-tunneled services (Minecraft, etc.)

`fail2ban` only ever sees nginx-ui's HTTP logs — it has no visibility
into raw TCP/UDP traffic tunneled through `frps`, like a Minecraft
server. This used to require touching iptables/nftables directly, which
conflicts with SoftEther, WireGuard, and Tailscale, all of which manage
their own firewall rules on this box — Tailscale's own reconciliation
silently wiped a rule inserted that way, unnoticed until it broke an
unrelated service. Doesn't touch the host firewall at all anymore.

`frps.toml` sets `proxyBindAddr = "127.0.0.1"` — every proxy, including
the existing HTTP(S) tunnel, is unreachable except via loopback. nginx
(which runs in `network_mode: host`, so it's reachable on every
interface on this box — public IP, Tailscale, LAN, all of it, same as
before) becomes the single entry point for everything, using its
`stream` module for raw TCP/UDP with `limit_conn` for per-source-IP
connection limiting.

**Protected by default, not opt-in per port.** `ratelimit-gen`
auto-discovers every active proxy directly from `frps`'s own dashboard
API and rate-limits all of them — you declare a port exactly once, in
`frpc.toml` (which you already have to touch to tunnel anything at
all), and it's protected automatically from there. `RATE_LIMIT_EXCLUDE_PORTS`
(`.env`) is the exception list for ports that should stay unlimited;
`RATE_LIMIT_WHITELIST_IPS` is the exception list for IPs that bypass
the limit on everything. Generates
`nginx-conf/streams-enabled/ratelimit.conf`, picked up automatically
via nginx-ui's own bundled `stream { include streams-enabled/*; }`
(confirmed straight from its source) — no manual paste into nginx-ui's
Streams panel needed, and it re-polls every 60s so newly added/removed
`frpc` proxies get picked up without a manual trigger, self-healing if
`nginx-conf-preflight`'s recovery ever wipes the generated file along
with everything else.

Required naming convention in `frpc.toml`: every `[[proxies]]` name
must end in `-<public_port>`, e.g. `"minecraft-java-25565"` — that's
what tells `ratelimit-gen` which public port to expose. `remotePort` in
that same block is a separate, INTERNAL-only port, deliberately
different from the public port in the name — nginx and frps can't both
bind the identical port number even on different addresses (a real
kernel-level bind conflict, confirmed by testing). Any proxy name not
matching the convention is skipped with a clear warning in
`docker logs ratelimit-gen`, not silently ignored.

Tested end-to-end against a constructed sample matching frp's own
confirmed Go struct fields (`TCPProxyConfig`/`UDPProxyConfig` both tag
the port as `json:"remotePort"`): a rate-limited port, an excluded
port, a malformed proxy name, an offline proxy, TCP and UDP together,
and — importantly — a transient `frps` API failure correctly
*preserving* the last-known-good config instead of blanking out
already-working rate limits until the next successful poll. Separately
confirmed the core `limit_conn` mechanism against a real live nginx
process: 5 simultaneous connections against a limit of 3 correctly got
3 accepted and 2 rejected, and a whitelisted IP correctly bypassed that
same limit entirely (nginx's documented empty-key idiom via a `geo`
block — IPs in `RATE_LIMIT_WHITELIST_IPS` get an empty tracking key,
which `limit_conn_zone` doesn't count at all).

**Honest caveat:** the API field path used (`.conf.remotePort`) is
confirmed directly from frp's own source, but there's no live `frps`
instance available to verify the *actual* response shape the way
everything else in this project was tested against the real thing. If
`frps` ever returns something genuinely unexpected, this fails loudly
in `docker logs ratelimit-gen` rather than silently generating an
empty or wrong config — check there first if a newly added proxy isn't
showing up as expected.

Applies to all traffic uniformly by default, no exceptions for
Tailscale/LAN/your own access unless you add yourself to
`RATE_LIMIT_WHITELIST_IPS` — everyone else goes through the same
`limit_conn`.

## Behind FRP with two nginx instances (Linode + home)

If some sites are hosted directly on Linode and others live at home behind
FRP, run **two separate stacks**:

- This folder (`nginx-ui-stack/`) on Linode: nginx-ui, certbot, fail2ban,
  and now `frps` — the tunnel entry point.
- A second, lighter stack (`nginx-ui-home-stack/`, a sibling project) on
  your local network: just nginx-ui and `frpc`. No certbot, no fail2ban —
  traffic arriving here has already been TLS-terminated and filtered at
  the Linode edge.

Real IPs survive the hop without needing FRP's Proxy Protocol feature,
because Linode's nginx-ui already terminates the public TLS connection and
re-proxies as a normal HTTP request — the client IP just rides through as
a standard `X-Forwarded-For` header, same as any nginx-behind-nginx setup:

1. **Linode nginx-ui** (see `nginx-sites/linode-tunneled-site.conf`)
   proxies the domain to `127.0.0.1:${TUNNEL_LOCAL_PORT}` — frps's local
   tunnel port — setting `X-Real-IP`/`X-Forwarded-For` from `$remote_addr`
   as usual. If Cloudflare orange-clouds the domain, uncomment the
   `set_real_ip_from`/`real_ip_header CF-Connecting-IP` lines first, so
   `$remote_addr` is already correct before it gets forwarded.
2. That connection travels through the frp tunnel (encrypted via
   `transport.tls`) to `frpc` at home, which hands it to home nginx-ui on
   `127.0.0.1:${HOME_TUNNEL_PORT}`.
3. **Home nginx-ui** (see `nginx-sites/home-tunnel-relay.conf`) trusts
   that loopback connection with `set_real_ip_from 127.0.0.1;` +
   `real_ip_header X-Forwarded-For;`, recovering the real client IP before
   proxying on to the actual backend service.

Setup order: fill in both `.env` files (`FRP_TOKEN` and the port numbers
must match exactly between the two), bring up the Linode stack first
(`docker compose up -d --build`), then the home stack — `frpc` will
connect out to `frps` automatically. Paste the two server blocks
into each nginx-ui's raw editor, swapping domains/ports/backend targets
for your actual services.

## frps dashboard

Once `frps` is up, its dashboard is at `http://<linode-ip>:${FRP_DASHBOARD_PORT}`
(login is `${FRP_DASHBOARD_USER}` / `${FRP_DASHBOARD_PASSWORD}` from `.env`)
— shows connected clients, active proxies, and traffic stats. Since it
binds `0.0.0.0`, consider restricting that port to your own IP in Linode's
Cloud Firewall / security group rather than leaving it open.

## Cloudflare real IP passthrough

If a site is Cloudflare-proxied, nginx would otherwise see every request
as coming from one of Cloudflare's own edge IPs rather than the actual
visitor — which matters a lot for fail2ban specifically: enough "bad"
traffic and it would eventually ban one of *Cloudflare's* IPs, breaking
the site for every visitor at once, not just an attacker.

`update-cloudflare-ips.sh` fetches Cloudflare's current IP ranges and
generates two files:
- `nginx-conf/conf.d/cloudflare-realip.conf` — `set_real_ip_from` for
  every Cloudflare range plus `real_ip_header CF-Connecting-IP`, so
  `$remote_addr` becomes the real visitor IP everywhere it's used
  (proxying, logging, fail2ban).
- `fail2ban/jail.d/00-ignoreip.local` — a `[DEFAULT] ignoreip` covering
  Cloudflare's ranges *and* private/loopback ranges (so fail2ban can
  never ban a Cloudflare edge IP, or anything on the Docker/tunnel side
  like `home-net`'s `172.30.0.0/24`, even on a request that somehow
  didn't get real-IP-rewritten).

**Run this for the first time only *after* `docker compose up -d` has
brought `nginx-ui` up successfully at least once** — check `docker logs
nginx-ui` shows "Nginx configurations directory initialized" and `ss
-tlnp` shows something bound to 80/443 first. nginx-ui only populates
its own base `nginx.conf`/`mime.types`/etc. into `nginx-conf/` when that
directory is *completely empty* on first boot (even an empty
subdirectory counts as non-empty for this check) — running this script
before that first successful boot puts a file in there first and
silently breaks nginx-ui's own initialization, with no error, just
`nginx: [emerg] open() "/etc/nginx/nginx.conf" failed`. After that first
successful boot, run it any time, including on a cron schedule.

```
./update-cloudflare-ips.sh
```

It's safe to run repeatedly (e.g. a weekly cron entry after that first
boot) — if the fetch ever fails, it leaves `cloudflare-realip.conf`
untouched rather than writing something empty. Needs `curl` on the host
(already present on most Debian installs). Any Cloudflare-proxied site's
config should `include /etc/nginx/conf.d/cloudflare-realip.conf;` inside
its `server {}` block — already done in
`nginx-sites/linode-tunneled-site.conf`; add it to any other
Cloudflare-proxied site you create too. Skip the include on any domain
that isn't Cloudflare-proxied.

**Your own whitelist**: add IPs/CIDRs to `FAIL2BAN_WHITELIST_IPS` in
`.env` (space-separated) — your own static IP, for instance, so a
mis-tuned jail or a false positive can't lock you out. Re-run
`./update-cloudflare-ips.sh` after editing it; the whitelist gets applied
every run regardless of whether the Cloudflare fetch itself succeeds, so
this always takes effect even with no network access.

## Updating

Don't just `docker pull` — `certbot` and `frps` are built from Dockerfiles,
so a bare pull won't touch them, and floating on `:latest` risks a silent
break (frp changes its `.toml` schema between major versions sometimes).

Instead: pin real version tags in `.env` (`NGINX_UI_VERSION`,
`CERTBOT_VERSION`, `FAIL2BAN_VERSION`, `FRPS_VERSION`), then run:

```
./update.sh
```

It pulls/rebuilds everything, recreates containers, and checks that every
service is running and nginx-ui's config is still valid. Terminal output
stays quiet either way — full detail only ever goes to
`update-failures.log`, and only if something actually failed.

- **On success**, it saves `.env` as `.env.last-good` — the known-working
  baseline for next time.
- **On failure**, it automatically restores `.env` from that baseline and
  redeploys the previously-working versions, so you're not left on a
  half-updated stack. It then logs the full failure output before exiting.
- **First run**: there's no baseline yet, so a failure on your very first
  `./update.sh` can't auto-revert — it'll say so and leave `.env` as-is
  for you to fix. Every successful run after that establishes a baseline
  the next failure can fall back to.

Bump versions in `.env` one at a time and deliberately, rather than
jumping straight to whatever's newest.

## Notes

- Since this is a *wildcard* cert, adding a new subdomain later never
  requires touching certbot again — just add a new server block in
  nginx-ui pointing at the same `fullchain.pem` / `privkey.pem`.
- `certbot renew` is idempotent and safe to leave looping indefinitely;
  it only actually renews inside Let's Encrypt's ~30-day-before-expiry
  window.
- If you rotate the Cloudflare token, just update `.env` and
  `docker compose up -d --build certbot` — the ini file regenerates on
  every container start.
