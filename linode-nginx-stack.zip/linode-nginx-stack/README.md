# nginx-ui + Cloudflare wildcard cert

Solves two things NPM couldn't:
- Raw nginx.conf / server block editing (nginx-ui edits real config files directly)
- One wildcard cert covering the root domain and every subdomain, issued via
  Cloudflare DNS-01 — so no port-80 HTTP-01 dance per subdomain, and no NPM
  proxying oddities in front of Nextcloud.

## Setup

1. Edit `.env` directly and fill in `ROOT_DOMAIN`, `CF_API_TOKEN`,
   `LE_EMAIL`. The Cloudflare token needs **Zone:DNS:Edit** scoped to just
   that zone — not the Global API key.

2. `docker compose up -d --build`

   The `certbot` container will request a cert for `ROOT_DOMAIN` and
   `*.ROOT_DOMAIN` on first boot, then check for renewal every 12 hours.
   Renewed certs auto-trigger `nginx -s reload` inside the `nginx-ui`
   container via the mounted docker socket — no manual reload needed.

3. Open the nginx-ui panel at `http://<host>:9000` and finish the initial
   admin account setup.

4. Certs land in `./certbot/certs/live/${ROOT_DOMAIN}/` on the host, which
   is mounted read-only into `nginx-ui` at `/etc/letsencrypt`. Reference
   them directly in any server block you write — no per-subdomain
   certificate needed since it's a wildcard.

## Standard subdomain (e.g. share.cosmoscraft.net)

Paste this into nginx-ui's raw config editor for that site:

```nginx
server {
    listen 443 ssl;
    server_name share.cosmoscraft.net;

    ssl_certificate     /etc/letsencrypt/live/cosmoscraft.net/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/cosmoscraft.net/privkey.pem;

    location / {
        proxy_pass http://embed-server:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

server {
    listen 80;
    server_name share.cosmoscraft.net;
    return 301 https://$host$request_uri;
}
```

## Nextcloud subdomain

This is the block NPM was mangling. Nextcloud needs a larger body size
ceiling, unbuffered proxying (so large uploads don't get held in memory or
truncated at NPM's default limits), and WebDAV-friendly headers:

```nginx
server {
    listen 443 ssl;
    server_name cloud.cosmoscraft.net;

    ssl_certificate     /etc/letsencrypt/live/cosmoscraft.net/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/cosmoscraft.net/privkey.pem;

    client_max_body_size 0;
    client_body_timeout 3600s;

    location / {
        proxy_pass http://nextcloud-fpm-or-web:80;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_request_buffering off;
        proxy_buffering off;
        proxy_max_temp_file_size 0;

        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }
}

server {
    listen 80;
    server_name cloud.cosmoscraft.net;
    return 301 https://$host$request_uri;
}
```

Adjust the `proxy_pass` target to whatever your Nextcloud compose stack
exposes (the nginx/FPM front container, not php-fpm directly).

## Fail2ban (nginx-ui log protection)

A `fail2ban` service now watches nginx-ui's access/error logs (mounted out
to `./nginx-logs` on the host) and bans repeat offenders — failed auth,
bot scanning, rate-limit abuse — directly via iptables on the host. It
runs with `network_mode: host` and `NET_ADMIN`/`NET_RAW` so it can
manage firewall rules itself; no external account or console needed,
unlike CrowdSec.

Jail definitions live in `./fail2ban/jail.d/nginx.local`. Ban state
persists in `./fail2ban/data` across restarts. To check active bans:

```
docker exec fail2ban fail2ban-client status nginx-http-auth
```

If you add rate limiting (`limit_req`) to any nginx-ui server blocks
later, the `nginx-limit-req` jail will already pick up those log lines.

## Behind FRP with two nginx instances (Linode + home)

If some sites are hosted directly on Linode and others live at home behind
FRP, run **two separate stacks**:

- This folder (`nginx-ui-stack/`) on Linode: nginx-ui, certbot, fail2ban,
  and now `frps` — the tunnel entry point.
- A second, lighter stack (`nginx-ui-home-stack/`, a sibling project) on
  your local network: just nginx-ui and `frpc`. No certbot, no fail2ban —
  traffic arriving here has already been TLS-terminated and filtered at
  the Linode edge.

Real IPs survive the hop without needing FRP's Proxy Protocol feature,
because Linode's nginx-ui already terminates the public TLS connection and
re-proxies as a normal HTTP request — the client IP just rides through as
a standard `X-Forwarded-For` header, same as any nginx-behind-nginx setup:

1. **Linode nginx-ui** (see `nginx-sites/linode-tunneled-site.conf`)
   proxies the domain to `127.0.0.1:${TUNNEL_LOCAL_PORT}` — frps's local
   tunnel port — setting `X-Real-IP`/`X-Forwarded-For` from `$remote_addr`
   as usual. If Cloudflare orange-clouds the domain, uncomment the
   `set_real_ip_from`/`real_ip_header CF-Connecting-IP` lines first, so
   `$remote_addr` is already correct before it gets forwarded.
2. That connection travels through the frp tunnel (encrypted via
   `transport.tls`) to `frpc` at home, which hands it to home nginx-ui on
   `127.0.0.1:${HOME_TUNNEL_PORT}`.
3. **Home nginx-ui** (see `nginx-sites/home-tunnel-relay.conf`) trusts
   that loopback connection with `set_real_ip_from 127.0.0.1;` +
   `real_ip_header X-Forwarded-For;`, recovering the real client IP before
   proxying on to the actual backend service.

Setup order: fill in both `.env` files (`FRP_TOKEN` and the port numbers
must match exactly between the two), bring up the Linode stack first
(`docker compose up -d --build`), then the home stack — `frpc` will
connect out to `frps` automatically. Paste the two server blocks
into each nginx-ui's raw editor, swapping domains/ports/backend targets
for your actual services.

## frps dashboard

Once `frps` is up, its dashboard is at `http://<linode-ip>:${FRP_DASHBOARD_PORT}`
(login is `${FRP_DASHBOARD_USER}` / `${FRP_DASHBOARD_PASSWORD}` from `.env`)
— shows connected clients, active proxies, and traffic stats. Since it
binds `0.0.0.0`, consider restricting that port to your own IP in Linode's
Cloud Firewall / security group rather than leaving it open.

## Updating

Don't just `docker pull` — `certbot` and `frps` are built from Dockerfiles,
so a bare pull won't touch them, and floating on `:latest` risks a silent
break (frp changes its `.toml` schema between major versions sometimes).

Instead: pin real version tags in `.env` (`NGINX_UI_VERSION`,
`CERTBOT_VERSION`, `FAIL2BAN_VERSION`, `FRPS_VERSION`), then run:

```
./update.sh
```

It pulls/rebuilds everything, recreates containers, and checks that every
service is running and nginx-ui's config is still valid. Terminal output
stays quiet either way — full detail only ever goes to
`update-failures.log`, and only if something actually failed.

- **On success**, it saves `.env` as `.env.last-good` — the known-working
  baseline for next time.
- **On failure**, it automatically restores `.env` from that baseline and
  redeploys the previously-working versions, so you're not left on a
  half-updated stack. It then logs the full failure output before exiting.
- **First run**: there's no baseline yet, so a failure on your very first
  `./update.sh` can't auto-revert — it'll say so and leave `.env` as-is
  for you to fix. Every successful run after that establishes a baseline
  the next failure can fall back to.

Bump versions in `.env` one at a time and deliberately, rather than
jumping straight to whatever's newest.

## Notes

- Since this is a *wildcard* cert, adding a new subdomain later never
  requires touching certbot again — just add a new server block in
  nginx-ui pointing at the same `fullchain.pem` / `privkey.pem`.
- `certbot renew` is idempotent and safe to leave looping indefinitely;
  it only actually renews inside Let's Encrypt's ~30-day-before-expiry
  window.
- If you rotate the Cloudflare token, just update `.env` and
  `docker compose up -d --build certbot` — the ini file regenerates on
  every container start.
