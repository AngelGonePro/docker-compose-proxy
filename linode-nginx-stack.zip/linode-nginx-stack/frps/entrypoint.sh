#!/bin/sh
# Renders frps.toml from frps.toml.src by substituting ${VAR} placeholders
# with plain sed — no gettext/envsubst dependency, so this works on any
# base image (Alpine, Debian, whatever this image happens to ship as).
set -e

if [ -z "$FRP_BIND_PORT" ] || [ -z "$FRP_TOKEN" ] || [ -z "$FRP_DASHBOARD_PORT" ] || [ -z "$FRP_DASHBOARD_USER" ] || [ -z "$FRP_DASHBOARD_PASSWORD" ]; then
  echo "FRP_BIND_PORT, FRP_TOKEN, FRP_DASHBOARD_PORT, FRP_DASHBOARD_USER, and FRP_DASHBOARD_PASSWORD must all be set in .env" >&2
  exit 1
fi

cp /etc/frp/frps.toml.src /etc/frp/frps.toml

for var in FRP_BIND_PORT FRP_TOKEN FRP_DASHBOARD_PORT FRP_DASHBOARD_USER FRP_DASHBOARD_PASSWORD; do
  val=$(eval echo "\$$var")
  esc_val=$(printf '%s' "$val" | sed -e 's/[\/&]/\\&/g')
  sed -i "s/\${$var}/$esc_val/g" /etc/frp/frps.toml
done

exec frps -c /etc/frp/frps.toml
