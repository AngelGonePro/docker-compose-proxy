#!/bin/sh
set -e

if [ -z "$FRP_BIND_PORT" ] || [ -z "$FRP_TOKEN" ] || [ -z "$FRP_DASHBOARD_PORT" ] || [ -z "$FRP_DASHBOARD_USER" ] || [ -z "$FRP_DASHBOARD_PASSWORD" ]; then
  echo "FRP_BIND_PORT, FRP_TOKEN, FRP_DASHBOARD_PORT, FRP_DASHBOARD_USER, and FRP_DASHBOARD_PASSWORD must all be set in .env" >&2
  exit 1
fi

envsubst < /etc/frp/frps.toml.template > /etc/frp/frps.toml

exec frps -c /etc/frp/frps.toml
