#!/bin/sh
# Usage: ./update.sh
#
# Pulls/rebuilds per the versions pinned in .env, recreates containers,
# verifies everything came back up, and:
#   - on success: records .env as the new known-good baseline (.env.last-good)
#   - on failure: reverts .env to that baseline, redeploys the old working
#     versions, and writes full failure detail to update-failures.log
#     (nothing is logged on success — this file only grows on real problems)

set -e
cd "$(dirname "$0")"

LOG_FILE="./update-failures.log"
LAST_GOOD=".env.last-good"
TMP_OUT=$(mktemp)
trap 'rm -f "$TMP_OUT"' EXIT

log_failure() {
  {
    echo "===== $(date -u +'%Y-%m-%dT%H:%M:%SZ') UPDATE FAILURE ====="
    cat "$TMP_OUT"
    echo ""
  } >> "$LOG_FILE"
}

revert_to_last_good() {
  if [ -f "$LAST_GOOD" ]; then
    echo "==> Reverting .env to last known-good versions and redeploying..." >&2
    cp "$LAST_GOOD" .env
    docker compose build --pull >> "$TMP_OUT" 2>&1 || true
    docker compose up -d >> "$TMP_OUT" 2>&1 || true
    echo "==> Reverted. Previously-working versions are running again." >&2
  else
    echo "==> No known-good baseline yet (this looks like the first run) —" >&2
    echo "    nothing to revert to. Fix the versions in .env and re-run." >&2
  fi
}

fail() {
  echo "$1" >> "$TMP_OUT"
  echo "[FAIL] $1 — see $LOG_FILE" >&2
  revert_to_last_good
  log_failure
  exit 1
}

echo "==> Updating (details only shown if something fails)..."

docker compose pull > "$TMP_OUT" 2>&1 || fail "docker compose pull failed"
docker compose build --pull >> "$TMP_OUT" 2>&1 || fail "docker compose build failed"
docker compose up -d >> "$TMP_OUT" 2>&1 || fail "docker compose up failed"

sleep 8

FAILED=0
for svc in $(docker compose config --services); do
  # One-shot services (restart: "no") exit 0 when done and just sit
  # there — checking for "running" state would always incorrectly flag
  # them as failed. Detect this from the compose config itself instead
  # of hardcoding service names, so any current or future one-shot
  # service (bootstrap, nginx-conf-preflight, etc.) is handled correctly
  # without needing update.sh edited every time one's added.
  restart_policy=$(docker compose config 2>/dev/null | awk -v s="$svc" '
    $0 ~ "^  "s":" {in_svc=1}
    in_svc && /^  [a-zA-Z]/ && $0 !~ "^  "s":" {in_svc=0}
    in_svc && /restart:/ {print $2; exit}
  ')
  if [ "$restart_policy" = "\"no\"" ] || [ "$restart_policy" = "no" ]; then
    exit_code=$(docker inspect --format='{{.State.ExitCode}}' "$svc" 2>/dev/null || echo "missing")
    if [ "$exit_code" != "0" ]; then
      echo "$svc (one-shot) did not complete successfully (exit code: $exit_code) — check docker logs $svc" >> "$TMP_OUT"
      FAILED=1
    fi
    continue
  fi
  state=$(docker compose ps --format '{{.State}}' "$svc" 2>/dev/null || echo "missing")
  if [ "$state" != "running" ]; then
    echo "$svc is not running (state: $state)" >> "$TMP_OUT"
    FAILED=1
  fi
done

if ! docker exec nginx-ui nginx -t >> "$TMP_OUT" 2>&1; then
  echo "nginx config test failed after update" >> "$TMP_OUT"
  FAILED=1
fi

if [ "$FAILED" -eq 1 ]; then
  echo "[FAIL] Update verification failed — see $LOG_FILE" >&2
  revert_to_last_good
  log_failure
  exit 1
fi

cp .env "$LAST_GOOD"
echo "==> Update complete and verified. Baseline recorded for future reverts."
