#!/bin/sh
# Runs once after nginx-ui and certbot come up. Does everything that was
# previously manual: completes nginx-ui's first-run setup using the admin
# account from .env (skipped if already set up), logs in, waits for
# certbot to actually issue the cert, then imports it into nginx-ui via
# its own API. No clicking, no SSH commands.
#
# Success/failure is judged by HTTP status code (curl -w), not by
# matching literal text in the JSON body — text matching breaks on any
# whitespace/formatting difference and can silently mis-detect success.
set -u

NGINX_UI_URL="http://nginx-ui:9000"
SECRET_FILE="/etc/nginx-ui/.install_secret"
CERT_DIR="/etc/letsencrypt/live/${ROOT_DOMAIN}"

log() { echo "[bootstrap] $*"; }

log "Waiting for nginx-ui API..."
i=0
until curl -fsS "$NGINX_UI_URL/api/install" -o /tmp/install_status.json 2>/dev/null; do
  i=$((i + 1))
  [ "$i" -ge 60 ] && { log "nginx-ui API never came up after 2m — giving up."; exit 1; }
  sleep 2
done

if ! jq -e . /tmp/install_status.json >/dev/null 2>&1; then
  log "nginx-ui returned unparseable JSON for /api/install: $(cat /tmp/install_status.json) — giving up."
  exit 1
fi
LOCKED=$(jq -r '.lock' /tmp/install_status.json)
if [ "$LOCKED" != "true" ] && [ "$LOCKED" != "false" ]; then
  log "Unexpected .lock value from /api/install: '$LOCKED' — giving up."
  exit 1
fi

if [ "$LOCKED" = "false" ]; then
  log "Completing first-run setup (admin user: ${NGINX_UI_ADMIN_USER})..."

  i=0
  until [ -s "$SECRET_FILE" ]; do
    i=$((i + 1))
    [ "$i" -ge 30 ] && { log "Install secret file never appeared — giving up."; exit 1; }
    sleep 2
  done
  SECRET=$(cat "$SECRET_FILE")

  HTTP_CODE=$(curl -s -o /tmp/setup_resp.json -w '%{http_code}' -X POST "$NGINX_UI_URL/api/setup/install" \
    -H "Content-Type: application/json" \
    -H "X-Install-Secret: $SECRET" \
    -d "{\"email\":\"${NGINX_UI_ADMIN_EMAIL}\",\"username\":\"${NGINX_UI_ADMIN_USER}\",\"password\":\"${NGINX_UI_ADMIN_PASSWORD}\"}")

  if [ "$HTTP_CODE" != "200" ]; then
    log "Setup call failed (HTTP $HTTP_CODE): $(cat /tmp/setup_resp.json)"
    exit 1
  fi
  log "First-run setup complete."
else
  log "nginx-ui already set up — skipping first-run setup."
fi

log "Logging in..."
i=0
while :; do
  HTTP_CODE=$(curl -s -o /tmp/login_resp.json -w '%{http_code}' -X POST "$NGINX_UI_URL/api/login" \
    -H "Content-Type: application/json" \
    -d "{\"name\":\"${NGINX_UI_ADMIN_USER}\",\"password\":\"${NGINX_UI_ADMIN_PASSWORD}\"}")
  [ "$HTTP_CODE" = "200" ] && break
  if [ "$HTTP_CODE" = "401" ]; then
    log "Login rejected (401) — wrong NGINX_UI_ADMIN_USER/PASSWORD in .env, not a transient issue. Response: $(cat /tmp/login_resp.json)"
    exit 1
  fi
  i=$((i + 1))
  if [ "$i" -ge 30 ]; then
    log "Login never succeeded (last HTTP $HTTP_CODE): $(cat /tmp/login_resp.json)"
    exit 1
  fi
  sleep 2
done

if ! jq -e . /tmp/login_resp.json >/dev/null 2>&1; then
  log "Login response was not valid JSON: $(cat /tmp/login_resp.json)"
  exit 1
fi
TOKEN=$(jq -r '.token // empty' /tmp/login_resp.json)
if [ -z "$TOKEN" ]; then
  log "Login succeeded (HTTP 200) but response had no token — check NGINX_UI_ADMIN_USER/PASSWORD in .env match the real account. Response: $(cat /tmp/login_resp.json)"
  exit 1
fi
log "Logged in."

log "Waiting for certbot to issue the certificate at $CERT_DIR..."
i=0
until [ -f "$CERT_DIR/fullchain.pem" ] && [ -f "$CERT_DIR/privkey.pem" ]; do
  i=$((i + 1))
  [ "$i" -ge 150 ] && { log "Cert never appeared after 5m — check certbot logs. Giving up."; exit 1; }
  sleep 2
done
log "Certificate found."

HTTP_CODE=$(curl -s -o /tmp/import_resp.json -w '%{http_code}' -X POST "$NGINX_UI_URL/api/cert_import" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d "{\"name\":\"${ROOT_DOMAIN}\",\"ssl_certificate_path\":\"$CERT_DIR/fullchain.pem\",\"ssl_certificate_key_path\":\"$CERT_DIR/privkey.pem\"}")

if [ "$HTTP_CODE" != "200" ]; then
  log "Import failed (HTTP $HTTP_CODE): $(cat /tmp/import_resp.json)"
  exit 1
fi
log "Certificate imported into nginx-ui as '${ROOT_DOMAIN}'."
log "Bootstrap complete."
