# nginx-ui (home) + frpc

Companion stack to `nginx-ui-stack/` on Linode. This one lives on your
local network and has no cert handling or fail2ban — it just relays
already-TLS-terminated, already-filtered traffic from the Linode edge to
your actual backend services.

## Setup

1. Copy `.env.example` to `.env`. Fill in:
   - `FRP_SERVER_ADDR` — Linode's public IP or hostname
   - `FRP_SERVER_PORT` — must match Linode's `FRP_BIND_PORT`
   - `FRP_TOKEN` — must match Linode's `FRP_TOKEN` exactly
   - `TUNNEL_LOCAL_PORT` — must match Linode's `TUNNEL_LOCAL_PORT` exactly
   - `HOME_TUNNEL_PORT` — the local port nginx-ui listens on for tunneled
     traffic (default 8080, plain HTTP)

2. Bring up the Linode stack first, then here:
   `docker compose up -d --build`

3. Open home nginx-ui's panel at `http://<local-ip>:${NGINX_UI_PORT}` and
   paste in server blocks like `nginx-examples/home-tunnel-relay.conf`
   for each tunneled domain, pointing `proxy_pass` at your real backend
   (Jellyfin, Nextcloud, etc.).

4. Check the tunnel connected:
   `docker logs frpc` — should show a successful login to frps.

## Adding more than HTTP traffic (game servers, etc.)

`frpc.toml.template` includes commented-out examples for a raw TCP proxy
(Minecraft Java) and a UDP proxy (Minecraft Bedrock) — uncomment and point
`localIP`/`localPort` at wherever that service actually runs, then
`docker compose up -d --build frpc` to pick up the change. These bypass
nginx entirely; players connect straight to `linode-ip:<remotePort>`.
Remember to open that `remotePort` in Linode's Cloud Firewall too, same as
you would for any other exposed port.

## Why no TLS or fail2ban here

Linode's nginx-ui already terminated the public HTTPS connection and
already ran the request through fail2ban's log-watching before forwarding
it through the tunnel. This instance only ever sees loopback connections
from `frpc` carrying an `X-Forwarded-For` header — plain HTTP is fine, and
duplicate cert/firewall logic here would just add moving parts without
adding protection.
