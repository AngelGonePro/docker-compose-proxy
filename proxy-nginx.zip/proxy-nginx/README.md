# nginx-ui (home) + certbot + frpc

Companion stack to `linode-nginx-stack/` on Linode. This one runs two
independent paths to the same backend services:

1. **Internet traffic**, via Linode → FRP tunnel → here, arriving already
   TLS-terminated as plain HTTP on an internal-only port.
2. **LAN/VPN traffic**, hitting this box's own 443 directly with a real,
   independently-issued wildcard cert — no round trip through Linode.

Both paths can point at the same backend (e.g. Jellyfin) — pick whichever
server block fits how a given device is connecting.

## Setup

1. Edit `.env` directly. Two groups of values:
   - **Cert vars** (`ROOT_DOMAIN`, `CF_API_TOKEN`, `LE_EMAIL`) — same
     domain as Linode's; the Cloudflare token can be the exact same one.
   - **Tunnel vars** (`FRP_SERVER_ADDR`, `FRP_SERVER_PORT`, `FRP_TOKEN`,
     `TUNNEL_LOCAL_PORT`) — must match Linode's `frps` config exactly.

2. Bring up the Linode stack first, then here:
   `docker compose up -d --build`

   `certbot` issues its own copy of the wildcard cert on first boot (same
   as Linode's, independently — DNS-01 doesn't mind two machines holding
   certs for the same name) and renews it on the same 12-hour check loop.

3. Open nginx-ui's panel at `http://<local-ip>:${NGINX_UI_PORT}` and add:
   - `nginx-sites/home-tunnel-relay.conf` — for the internet path
     (internal port only, plain HTTP, trusts frpc's forwarded IP)
   - `nginx-sites/home-direct-lan-vpn.conf` — for the LAN/VPN path
     (real HTTPS, no tunnel involved)

   Point both at the same backend, or split services between paths
   however makes sense.

4. Check the tunnel connected: `docker logs frpc`

## Networking

`nginx-ui`, `certbot`, and `frpc` share a Docker bridge network
(`home-net`, fixed at `172.30.0.0/24`) instead of host networking — this
keeps `HOME_TUNNEL_PORT` unpublished (only frpc's container can reach it,
never the LAN or a port-forward) and lets nginx-ui trust
`set_real_ip_from 172.30.0.0/24` reliably instead of guessing Docker's
default bridge range.

Only `HTTP_PORT`/`HTTPS_PORT`/`NGINX_UI_PORT` are published to the host —
these should reach your LAN/VPN interface only. Don't port-forward them
on your router; that would create a second, uncontrolled entry point
alongside the Linode edge (no fail2ban, no WAF) that defeats the point of
routing internet traffic through Linode in the first place.

## Adding more than HTTP traffic (game servers, etc.)

`frpc/frpc.toml` includes commented-out entries for a raw TCP proxy
(Minecraft Java) and a UDP proxy (Minecraft Bedrock) — uncomment and set
`localIP` to either another service's Compose name (if it's in this
project) or the real LAN IP of the physical machine running it, then
`docker compose up -d --build frpc`. These bypass nginx entirely; players
connect straight to `linode-ip:<remotePort>`. Remember to open that
`remotePort` in Linode's Cloud Firewall too.
