# nginx-ui (home) + certbot + frpc

Companion stack to `linode-nginx-stack/` on Linode.

## Install / update

Use the one command in the repository's main README (docker-compose-proxy).
It installs a fresh copy and updates an existing one without touching `.env`
values, `frpc/frpc.toml` once you've edited it, or runtime state.

This stack runs two independent paths to the same backend services:

1. **Internet traffic**, via Linode → FRP tunnel → here, arriving already
   TLS-terminated as plain HTTP on an internal-only port.
2. **LAN/VPN traffic**, hitting this box's own 443 directly with a real,
   independently-issued wildcard cert — no round trip through Linode.

Both paths can point at the same backend (e.g. Jellyfin) — pick whichever
server block fits how a given device is connecting.

## Setup

1. Edit `.env` directly. Three groups of values:
   - **Cert vars** (`ROOT_DOMAIN`, `CF_API_TOKEN`, `LE_EMAIL`) — same
     domain as Linode's; the Cloudflare token can be the exact same one.
   - **Admin account** (`NGINX_UI_ADMIN_EMAIL`, `NGINX_UI_ADMIN_USER`,
     `NGINX_UI_ADMIN_PASSWORD`) — used by `bootstrap` to set up this
     nginx-ui instance automatically.
   - **Tunnel vars** (`FRP_SERVER_ADDR`, `FRP_SERVER_PORT`, `FRP_TOKEN`,
     `TUNNEL_LOCAL_PORT`) — must match Linode's `frps` config exactly.

2. Bring up the Linode stack first, then here:
   `docker compose up -d --build`

   `nginx-conf-preflight` runs first and clears `nginx-conf/` automatically
   if it's in a specific broken state (non-empty but missing `nginx.conf`),
   so nginx-ui's own first-boot seeding runs correctly — no manual
   directory surgery needed on any deploy.

   `certbot` issues its own copy of the wildcard cert on first boot (same
   as Linode's, independently — DNS-01 doesn't mind two machines holding
   certs for the same name), trying Let's Encrypt first and falling back
   to ZeroSSL automatically if that fails — most commonly LE's rate limit,
   which is worth knowing is *shared* with the Linode stack's own certbot
   since both request the identical domain pair. Retries every 15 minutes
   if both providers fail, and renews on the same 12-hour check loop
   afterward. `bootstrap` completes nginx-ui's first-run setup and imports
   that cert automatically — check `docker logs bootstrap` if anything
   looks off.

3. Open nginx-ui's panel at `http://<local-ip>:${NGINX_UI_PORT}` and add:
   - `nginx-sites/home-tunnel-relay.conf` — for the internet path
     (internal port only, plain HTTP, trusts frpc's forwarded IP)
   - `nginx-sites/home-direct-lan-vpn.conf` — for the LAN/VPN path
     (real HTTPS, no tunnel involved)
   - `nginx-sites/threatmap.conf` — optional, the wg-vpn-gateway threat map
     (port 80 for Cloudflare Tunnel, 443 for local visits)

   Point both at the same backend, or split services between paths
   however makes sense. This part stays manual — it needs your actual
   backend IPs/ports, which only you know.

4. Check the tunnel connected: `docker logs frpc`

### Retrofitting onto an already-running install

Same as the Linode stack: if this nginx-ui was already set up manually,
set `NGINX_UI_ADMIN_USER`/`NGINX_UI_ADMIN_PASSWORD` in `.env` to match
that real account, delete any broken cert entry in the panel, then
`docker compose up -d bootstrap`.

## fail2ban: banning abusive visitors (optional)

Set `COMPOSE_PROFILES=firewall` in `.env` and run the install/update command.
It bans visitors who fail logins, hit rate limits, scan for exploits or use
known bad bots (same jails as the Linode), including visitors coming through
Cloudflare Tunnel, by their real address.

- **Real addresses.** Every tunnel visitor reaches nginx from `cloudflared`.
  nginx takes the visitor's address from Cloudflare's `CF-Connecting-IP`
  header, but **only** on connections from `CLOUDFLARED_SOURCE_IPS`. Anyone
  else sending that header is ignored, so nobody on the LAN can fake an
  address to get someone banned or to dodge a ban. With `cloudflared` in its
  own Docker compose project (the usual setup) it appears as `172.30.0.1`,
  the default. If your `cloudflared` uses `network_mode: host`, set this VM's
  LAN address instead (e.g. `10.0.0.100`).
- **Bans** go in nginx's deny list (`nginx-conf/conf.d/fail2ban-denylist.conf`):
  a firewall ban couldn't tell tunnel visitors apart. A banned visitor gets
  `403` on every site here. IPv6 bans cover the whole block
  (`FAIL2BAN_IPV6_BAN_PREFIX`, default `/64`).
- **Never banned:** loopback, private LAN ranges (which include Docker and
  `cloudflared` itself), Tailscale (`100.64.0.0/10`, `fd7a:115c:a1e0::/48`),
  private and link-local IPv6, and `FAIL2BAN_WHITELIST_IPS`.
- `fail2ban-setup` writes those settings from `.env` each time the stack
  starts. After changing them, run the install/update command (or
  `docker compose up -d`).
- **Threat map:** set `DASHBOARD_FAIL2BAN_DB_DIR=/root/proxy-nginx/fail2ban/data/db`
  in wg-vpn-gateway's `.env` (same VM) and the bans appear on the map as
  `fail2ban <jail>`.

Checks:
```bash
docker logs fail2ban-setup                                   # what it set up
docker exec fail2ban-home fail2ban-client status             # the four jails
docker exec fail2ban-home fail2ban-client status nginx-http-auth   # current bans
tail -3 nginx-logs/access.log    # tunnel visitors should show real addresses, not 172.30.0.1
```

## Updating

Same as the Linode stack — `certbot` and `frpc` are Dockerfile-built, so
a bare `docker pull` won't touch them. Pin real versions in `.env`
(`NGINX_UI_VERSION`, `CERTBOT_VERSION`, `FRPC_VERSION`), then run
`./update.sh`.

It rebuilds everything, recreates containers, and checks container
status, nginx-ui's config validity, and that `frpc` actually reconnected.
Terminal output stays quiet — full detail only goes to
`update-failures.log`, and only on real failures. On success it saves
`.env.last-good` as the new baseline; on failure it puts the version pins
(`*_VERSION`) back to that baseline, keeps every other `.env` setting, and
redeploys the previously-working versions
automatically (first run has no baseline to fall back to — see the
Linode README for that case, same behavior here).

One thing specific to this pair: `FRPS_VERSION` (Linode) and
`FRPC_VERSION` (here) should generally be kept on the same major version
as each other — check both before bumping either one.

## Networking

`nginx-ui`, `certbot`, and `frpc` share a Docker bridge network
(`home-net`, fixed at `172.30.0.0/24`) instead of host networking — this
keeps `HOME_TUNNEL_PORT` unpublished (only frpc's container can reach it,
never the LAN or a port-forward) and lets nginx-ui trust
`set_real_ip_from 172.30.0.0/24` reliably instead of guessing Docker's
default bridge range.

Only `HTTP_PORT`/`HTTPS_PORT`/`NGINX_UI_PORT` are published to the host —
these should reach your LAN/VPN interface only. Don't port-forward them
on your router; that would create a second, uncontrolled entry point
alongside the Linode edge (no fail2ban, no WAF) that defeats the point of
routing internet traffic through Linode in the first place.

**If `docker compose up` fails with a "Pool overlaps" error**: the fixed
`172.30.0.0/24` subnet collided with a network from another Compose
project already running on this host (Docker auto-assigns subnets from
the same `172.17.0.0/16`-ish range, so this can happen if you're also
running the Nextcloud or NamelessMC stacks here). Fix: change the
`subnet:` value in `docker-compose.yml`'s `networks.home-net.ipam.config`
to something unused — check `docker network inspect $(docker network ls -q) | grep Subnet`
to see what's already taken — then update the `set_real_ip_from` line in
`nginx-sites/home-tunnel-relay.conf` to match.

## Adding more than HTTP traffic (game servers, etc.)

`frpc/frpc.toml` includes commented-out entries for a raw TCP proxy
(Minecraft Java) and a UDP proxy (Minecraft Bedrock) — uncomment and set
`localIP` to either another service's Compose name (if it's in this
project) or the real LAN IP of the physical machine running it, then
`docker compose up -d --build frpc`. These bypass nginx entirely; players
connect straight to `linode-ip:<remotePort>`. Remember to open that
`remotePort` in Linode's Cloud Firewall too.
