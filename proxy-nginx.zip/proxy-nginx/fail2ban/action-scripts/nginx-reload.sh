#!/bin/sh
# Tests nginx's config and reloads it, inside the nginx-ui container.
# The fail2ban image has no "docker" command, so this talks to Docker's
# API over the mounted socket with curl (which the image does have).
# A config that doesn't test clean is never loaded — nginx keeps running
# the last good one. Exit code: 0 = reloaded.
C="${NGINX_CONTAINER:-nginx-ui-home}"
SOCK=/var/run/docker.sock
API=http://localhost

run() { # json-array-of-args -> succeeds if the command exits 0 in the container
  id=$(curl -sf --unix-socket "$SOCK" -X POST -H 'Content-Type: application/json' \
         -d "{\"Cmd\":$1,\"AttachStdout\":true,\"AttachStderr\":true}" "$API/containers/$C/exec" \
       | grep -o '"Id":"[0-9a-f]*"' | cut -d'"' -f4)
  [ -n "$id" ] || return 1
  # waits until the command has finished
  curl -sf --unix-socket "$SOCK" -X POST -H 'Content-Type: application/json' \
       -d '{"Detach":false,"Tty":false}' "$API/exec/$id/start" -o /dev/null || return 1
  i=0
  while [ $i -lt 10 ]; do
    code=$(curl -sf --unix-socket "$SOCK" "$API/exec/$id/json" | grep -o '"ExitCode":-\{0,1\}[0-9]*' | cut -d: -f2)
    running=$(curl -sf --unix-socket "$SOCK" "$API/exec/$id/json" | grep -o '"Running":[a-z]*' | cut -d: -f2)
    [ "$running" = false ] && { [ "$code" = 0 ]; return; }
    sleep 0.5; i=$((i + 1))
  done
  return 1
}

if command -v docker >/dev/null 2>&1; then
  docker exec "$C" nginx -t >/dev/null 2>&1 && docker exec "$C" nginx -s reload >/dev/null 2>&1
else
  run '["nginx","-t"]' && run '["nginx","-s","reload"]'
fi
