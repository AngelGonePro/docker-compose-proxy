#!/bin/sh
# Usage: ./update.sh
#
# Pulls/rebuilds per the versions pinned in .env, recreates containers,
# verifies everything came back up, and:
#   - on success: records .env as the new known-good baseline (.env.last-good)
#   - on failure: puts the *_VERSION pins in .env back to that baseline
#     (nothing else in .env is touched), redeploys the old working
#     versions, and writes full failure detail to update-failures.log
#     (nothing is logged on success — this file only grows on real problems)

set -e
cd "$(dirname "$0")"

LOG_FILE="./update-failures.log"
LAST_GOOD=".env.last-good"
TMP_OUT=$(mktemp)
trap 'rm -f "$TMP_OUT"' EXIT

log_failure() {
  {
    echo "===== $(date -u +'%Y-%m-%dT%H:%M:%SZ') UPDATE FAILURE ====="
    cat "$TMP_OUT"
    echo ""
  } >> "$LOG_FILE"
}

revert_to_last_good() {
  if [ -f "$LAST_GOOD" ]; then
    echo "==> Reverting the pinned versions (*_VERSION in .env) to the last known-good ones and redeploying..." >&2
    echo "    (all your other .env settings are kept as they are)" >&2
    # Only the version pins go back — copying the whole old .env would
    # silently undo settings changed since the last good update.
    awk 'NR == FNR { if ($0 ~ /^[A-Za-z0-9_]+_VERSION=/) { k = substr($0, 1, index($0, "=") - 1); v[k] = $0 } next }
         { if ($0 ~ /^[A-Za-z0-9_]+_VERSION=/) { k = substr($0, 1, index($0, "=") - 1); if (k in v) { print v[k]; next } } print }' \
      "$LAST_GOOD" .env > .env.revert-tmp && cat .env.revert-tmp > .env
    rm -f .env.revert-tmp
    docker compose build --pull >> "$TMP_OUT" 2>&1 || true
    docker compose up -d >> "$TMP_OUT" 2>&1 || true
    echo "==> Reverted. Previously-working versions are running again." >&2
  else
    echo "==> No known-good baseline yet (this looks like the first run) —" >&2
    echo "    nothing to revert to. Fix the versions in .env and re-run." >&2
  fi
}

fail() {
  echo "$1" >> "$TMP_OUT"
  echo "[FAIL] $1 — see $LOG_FILE" >&2
  revert_to_last_good
  log_failure
  exit 1
}

echo "==> Updating (details only shown if something fails)..."

UPDATE_START=$(date -u +'%Y-%m-%dT%H:%M:%SZ')

# --ignore-buildable: images this stack builds itself are never looked up on Docker Hub
docker compose pull --ignore-buildable > "$TMP_OUT" 2>&1 || fail "docker compose pull failed"
docker compose build --pull >> "$TMP_OUT" 2>&1 || fail "docker compose build failed"
docker compose up -d >> "$TMP_OUT" 2>&1 || fail "docker compose up failed"

# Force a fresh reconnect attempt so the login-success check below is
# meaningful even when frpc's own config/image didn't change this run
# (in which case "up -d" wouldn't have recreated it, and there'd be no
# new login message to check for).
docker compose restart frpc >> "$TMP_OUT" 2>&1 || true

sleep 8

FAILED=0
for svc in $(docker compose config --services); do
  # Ask Docker about the actual container instead of parsing compose
  # output (newer Compose prints restart: 'no' with single quotes, which
  # the old text match missed and wrongly failed every update). One-shot
  # services (restart policy "no", e.g. bootstrap, nginx-conf-preflight)
  # pass if they're still running or exited 0; everything else must be
  # running.
  cid=$(docker compose ps -a -q "$svc" 2>/dev/null | head -n 1)
  if [ -z "$cid" ]; then
    echo "$svc has no container after the update" >> "$TMP_OUT"
    FAILED=1
    continue
  fi
  policy=$(docker inspect --format='{{.HostConfig.RestartPolicy.Name}}' "$cid" 2>/dev/null || echo "missing")
  state=$(docker inspect --format='{{.State.Status}}' "$cid" 2>/dev/null || echo "missing")
  if [ "$policy" = "no" ] || [ -z "$policy" ]; then
    exit_code=$(docker inspect --format='{{.State.ExitCode}}' "$cid" 2>/dev/null || echo "missing")
    if [ "$state" != "running" ] && [ "$exit_code" != "0" ]; then
      echo "$svc (one-shot) did not complete successfully (state: $state, exit code: $exit_code) — check docker logs $svc" >> "$TMP_OUT"
      FAILED=1
    fi
    continue
  fi
  if [ "$state" != "running" ]; then
    echo "$svc is not running (state: $state)" >> "$TMP_OUT"
    FAILED=1
  fi
done

if ! docker exec nginx-ui-home nginx -t >> "$TMP_OUT" 2>&1; then
  echo "nginx config test failed after update" >> "$TMP_OUT"
  FAILED=1
fi

if ! docker logs frpc --since "$UPDATE_START" 2>&1 | grep -qi "login to server success"; then
  echo "frpc did not show a successful login since this update started" >> "$TMP_OUT"
  FAILED=1
fi

if [ "$FAILED" -eq 1 ]; then
  echo "[FAIL] Update verification failed — see $LOG_FILE" >&2
  revert_to_last_good
  log_failure
  exit 1
fi

cp .env "$LAST_GOOD"
echo "==> Update complete and verified. Baseline recorded for future reverts."
