#!/bin/sh
# Usage: ./deploy-update.sh <zip-url> <target-dir>
# Example:
#   ./deploy-update.sh https://raw.githubusercontent.com/AngelGonePro/docker-compose-proxy/refs/heads/main/linode-nginx-stack.zip linode-nginx-stack
#
# Safely fetches a fresh zip and applies it to an EXISTING deployment
# without destroying runtime state — certs, nginx-ui's managed configs,
# its database, ban history, logs, and (critically) your real .env
# values all survive. A plain overwrite would clobber .env with the
# template's placeholder values, since .env genuinely is part of what's
# shipped — this exists specifically to prevent that.
#
# .env is MERGED, not overwritten or blindly preserved: existing values
# for keys you already have stay exactly as they are; new keys the
# template adds (e.g. a new feature added since your last deploy) get
# appended with their default so you don't silently miss them.
set -eu

for cmd in curl python3; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing dependency: $cmd" >&2
    echo "Install it first: sudo apt update && sudo apt install -y $cmd" >&2
    exit 1
  fi
done

ZIP_URL="${1:?Usage: $0 <zip-url> <target-dir>}"
TARGET_DIR="${2:?Usage: $0 <zip-url> <target-dir>}"

# Paths that hold runtime state, never touched by an update regardless
# of whether they happen to appear in the zip.
PROTECTED_PATHS="
nginx-conf
nginx-ui-data
certbot/certs
certbot/logs
certbot/www
fail2ban/data
fail2ban/jail.d/00-ignoreip.local
nginx-logs
.env
.env.last-good
update-failures.log
"

TMP_ZIP=$(mktemp)
TMP_EXTRACT=$(mktemp -d)
trap 'rm -f "$TMP_ZIP"; rm -rf "$TMP_EXTRACT"' EXIT

echo "==> Downloading $ZIP_URL"
curl -fsSL -o "$TMP_ZIP" "$ZIP_URL"

echo "==> Extracting (stripping the top-level folder, matching your existing convention)"
python3 - "$TMP_ZIP" "$TMP_EXTRACT" << 'PYEOF'
import zipfile, os, sys
zip_path, extract_to = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(zip_path) as z:
    for member in z.namelist():
        parts = member.split("/", 1)
        if len(parts) > 1 and parts[1]:
            target = os.path.join(extract_to, parts[1])
            if not member.endswith("/"):
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with open(target, "wb") as f:
                    f.write(z.read(member))
PYEOF

is_protected() {
  path="$1"
  for p in $PROTECTED_PATHS; do
    case "$path" in
      "$p"|"$p"/*) return 0 ;;
    esac
  done
  return 1
}

echo "==> Copying updated files (skipping protected runtime paths)"
mkdir -p "$TARGET_DIR"
( cd "$TMP_EXTRACT" && find . -type f ) | sed 's#^\./##' | while IFS= read -r relpath; do
  if is_protected "$relpath"; then
    continue
  fi
  mkdir -p "$TARGET_DIR/$(dirname "$relpath")"
  cp "$TMP_EXTRACT/$relpath" "$TARGET_DIR/$relpath"
done

echo "==> Merging .env"
if [ -f "$TARGET_DIR/.env" ] && [ -f "$TMP_EXTRACT/.env" ]; then
  NEW_KEYS=""
  while IFS= read -r line; do
    case "$line" in
      \#*|"") continue ;;
    esac
    key=$(echo "$line" | cut -d= -f1)
    if ! grep -q "^${key}=" "$TARGET_DIR/.env" 2>/dev/null; then
      NEW_KEYS="${NEW_KEYS}${line}
"
    fi
  done < "$TMP_EXTRACT/.env"

  if [ -n "$NEW_KEYS" ]; then
    {
      echo ""
      echo "# --- New in this update ($(date -u +'%Y-%m-%dT%H:%M:%SZ')) — review these ---"
      printf '%s' "$NEW_KEYS"
    } >> "$TARGET_DIR/.env"
    echo "    New .env keys added (defaults from the template) — review the bottom of $TARGET_DIR/.env:"
    printf '%s' "$NEW_KEYS" | grep -v '^#' | grep -v '^$' | sed 's/^/      /'
  else
    echo "    No new .env keys — nothing to add."
  fi
  echo "    All your existing values were left exactly as they were."
elif [ -f "$TMP_EXTRACT/.env" ]; then
  cp "$TMP_EXTRACT/.env" "$TARGET_DIR/.env"
  echo "    No existing .env found — copied the template as a starting point. Fill in your real values before deploying."
fi

echo ""
echo "==> Done. Review any new .env keys, then run:"
echo "    cd $TARGET_DIR && docker compose up -d --remove-orphans"
