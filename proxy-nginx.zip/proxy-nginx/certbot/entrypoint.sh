#!/bin/sh
set -e

CRED_FILE=/etc/letsencrypt/cloudflare.ini
DEPLOY_HOOK="docker exec nginx-ui-home nginx -s reload"

if [ -z "$ROOT_DOMAIN" ] || [ -z "$CF_API_TOKEN" ] || [ -z "$LE_EMAIL" ]; then
  echo "ROOT_DOMAIN, CF_API_TOKEN, and LE_EMAIL must all be set in .env" >&2
  exit 1
fi

# Regenerate the Cloudflare credentials file from the env var on every start
cat > "$CRED_FILE" <<CFEOF
dns_cloudflare_api_token = ${CF_API_TOKEN}
CFEOF
chmod 600 "$CRED_FILE"

STAGING_FLAG=""
if [ "${LE_STAGING:-false}" = "true" ]; then
  STAGING_FLAG="--server https://acme-staging-v02.api.letsencrypt.org/directory"
  echo "LE_STAGING=true — using Let's Encrypt's staging environment. Certs issued this way are NOT trusted by browsers." >&2
fi

# Tries Let's Encrypt first, falls back automatically to ZeroSSL (a fully
# separate CA with its own rate-limit pool, no account signup needed —
# just an email) if LE is unavailable for any reason, most commonly its
# "5 certs per exact domain set per 168h" limit, which is shared across
# ANY client requesting that domain set and easy to hit during initial
# setup. Whichever provider succeeds gets recorded in certbot's own
# per-lineage renewal config, so every future automatic renewal keeps
# using that same provider — nothing to remember or re-select.
try_issue_letsencrypt() {
  certbot certonly \
    $STAGING_FLAG \
    --dns-cloudflare \
    --dns-cloudflare-credentials "$CRED_FILE" \
    --dns-cloudflare-propagation-seconds 30 \
    -d "${ROOT_DOMAIN}" \
    -d "*.${ROOT_DOMAIN}" \
    --agree-tos \
    --no-eff-email \
    -m "${LE_EMAIL}" \
    --deploy-hook "$DEPLOY_HOOK" \
    --non-interactive
}

try_issue_zerossl() {
  echo "$(date -u +'%Y-%m-%dT%H:%M:%SZ') Falling back to ZeroSSL..." >&2

  EAB_RESP=$(curl -fsS https://api.zerossl.com/acme/eab-credentials-email --data "email=${LE_EMAIL}" 2>/tmp/zerossl_curl_err.log) || {
    echo "Failed to reach ZeroSSL's EAB endpoint: $(cat /tmp/zerossl_curl_err.log)" >&2
    return 1
  }

  # Parsed with grep/cut rather than jq — kept this container's dependency
  # list as small as possible after the frps/frpc base-image lesson.
  EAB_KID=$(printf '%s' "$EAB_RESP" | grep -o '"eab_kid":"[^"]*"' | cut -d'"' -f4)
  EAB_HMAC=$(printf '%s' "$EAB_RESP" | grep -o '"eab_hmac_key":"[^"]*"' | cut -d'"' -f4)

  if [ -z "$EAB_KID" ] || [ -z "$EAB_HMAC" ]; then
    echo "ZeroSSL EAB response missing expected fields: $EAB_RESP" >&2
    return 1
  fi

  certbot certonly \
    --server https://acme.zerossl.com/v2/DV90 \
    --eab-kid "$EAB_KID" \
    --eab-hmac-key "$EAB_HMAC" \
    --dns-cloudflare \
    --dns-cloudflare-credentials "$CRED_FILE" \
    --dns-cloudflare-propagation-seconds 30 \
    -d "${ROOT_DOMAIN}" \
    -d "*.${ROOT_DOMAIN}" \
    --agree-tos \
    --no-eff-email \
    -m "${LE_EMAIL}" \
    --deploy-hook "$DEPLOY_HOOK" \
    --non-interactive \
    --cert-name "${ROOT_DOMAIN}"
}

# Keep trying — both providers, in order — until issuance succeeds. Runs
# fully unattended: no manual commands needed on any deploy, ever. Each
# failure is caught and retried on a timer instead of crashing the
# container (the old version's bare `certonly` under `set -e` would exit
# the whole script on failure, and the restart policy would just retry
# against the SAME rate-limited provider on every crash-restart).
while [ ! -d "/etc/letsencrypt/live/${ROOT_DOMAIN}" ]; do
  if try_issue_letsencrypt; then
    echo "$(date -u +'%Y-%m-%dT%H:%M:%SZ') Issued via Let's Encrypt." >&2
    break
  fi
  echo "$(date -u +'%Y-%m-%dT%H:%M:%SZ') Let's Encrypt issuance failed (likely rate-limited) — trying ZeroSSL..." >&2
  if try_issue_zerossl; then
    echo "$(date -u +'%Y-%m-%dT%H:%M:%SZ') Issued via ZeroSSL." >&2
    break
  fi
  echo "$(date -u +'%Y-%m-%dT%H:%M:%SZ') Both providers failed this round — retrying in 15m." >&2
  sleep 15m
done

# Check for renewal twice a day; certbot only actually renews inside the
# ~30-day window, automatically against whichever provider (LE or
# ZeroSSL) originally issued each lineage. A single failed attempt (e.g.
# transient DNS propagation issue) shouldn't kill the container — log it
# and retry on the next cycle instead of crash-looping.
while true; do
  if ! certbot renew --deploy-hook "$DEPLOY_HOOK" --quiet; then
    echo "$(date -u +'%Y-%m-%dT%H:%M:%SZ') certbot renew failed — will retry in 12h" >&2
  fi
  sleep 12h
done
