#!/bin/sh
set -e

CRED_FILE=/etc/letsencrypt/cloudflare.ini
DEPLOY_HOOK="docker exec nginx-ui-home nginx -s reload"

if [ -z "$ROOT_DOMAIN" ] || [ -z "$CF_API_TOKEN" ] || [ -z "$LE_EMAIL" ]; then
  echo "ROOT_DOMAIN, CF_API_TOKEN, and LE_EMAIL must all be set in .env" >&2
  exit 1
fi

# Regenerate the Cloudflare credentials file from the env var on every start
cat > "$CRED_FILE" <<EOF
dns_cloudflare_api_token = ${CF_API_TOKEN}
EOF
chmod 600 "$CRED_FILE"

# Issue the wildcard + root cert only if it doesn't already exist
if [ ! -d "/etc/letsencrypt/live/${ROOT_DOMAIN}" ]; then
  certbot certonly \
    --dns-cloudflare \
    --dns-cloudflare-credentials "$CRED_FILE" \
    --dns-cloudflare-propagation-seconds 30 \
    -d "${ROOT_DOMAIN}" \
    -d "*.${ROOT_DOMAIN}" \
    --agree-tos \
    --no-eff-email \
    -m "${LE_EMAIL}" \
    --deploy-hook "$DEPLOY_HOOK" \
    --non-interactive
fi

# Check for renewal twice a day; certbot only actually renews inside the ~30-day window
while true; do
  certbot renew --deploy-hook "$DEPLOY_HOOK" --quiet
  sleep 12h
done
