#!/bin/sh
set -e

if [ -z "$FRP_SERVER_ADDR" ] || [ -z "$FRP_TOKEN" ] || [ -z "$TUNNEL_LOCAL_PORT" ] || [ -z "$HOME_TUNNEL_PORT" ]; then
  echo "FRP_SERVER_ADDR, FRP_TOKEN, TUNNEL_LOCAL_PORT, and HOME_TUNNEL_PORT must all be set in .env" >&2
  exit 1
fi

envsubst < /etc/frp/frpc.toml.template > /etc/frp/frpc.toml

exec frpc -c /etc/frp/frpc.toml
