#!/bin/sh
# Renders frpc.toml from frpc.toml.src by substituting ${VAR} placeholders
# with plain sed — no gettext/envsubst dependency, so this works on any
# base image (Alpine, Debian, whatever this image happens to ship as).
set -e

if [ -z "$FRP_SERVER_ADDR" ] || [ -z "$FRP_TOKEN" ] || [ -z "$TUNNEL_LOCAL_PORT" ] || [ -z "$HOME_TUNNEL_PORT" ]; then
  echo "FRP_SERVER_ADDR, FRP_TOKEN, TUNNEL_LOCAL_PORT, and HOME_TUNNEL_PORT must all be set in .env" >&2
  exit 1
fi

cp /etc/frp/frpc.toml.src /etc/frp/frpc.toml

for var in FRP_SERVER_ADDR FRP_SERVER_PORT FRP_TOKEN HOME_TUNNEL_PORT TUNNEL_LOCAL_PORT; do
  val=$(eval echo "\$$var")
  esc_val=$(printf '%s' "$val" | sed -e 's/[\/&]/\\&/g')
  sed -i "s/\${$var}/$esc_val/g" /etc/frp/frpc.toml
done

exec frpc -c /etc/frp/frpc.toml
